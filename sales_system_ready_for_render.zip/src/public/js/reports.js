/**
 * ملف JavaScript لصفحة التقارير
 */

// تحميل تقرير المبيعات
function loadSalesReport(period = 'daily', dateFrom = '', dateTo = '') {
  $.ajax({
    url: `/api/reports/sales?period=${period}&dateFrom=${dateFrom}&dateTo=${dateTo}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const salesData = response.salesData;
      const summary = response.summary;
      
      // عرض ملخص التقرير
      $('#total-orders').text(summary.totalOrders);
      $('#total-sales').text(formatCurrency(summary.totalSales));
      $('#total-discounts').text(formatCurrency(summary.totalDiscounts));
      $('#total-taxes').text(formatCurrency(summary.totalTaxes));
      $('#total-final-sales').text(formatCurrency(summary.totalFinalSales));
      
      // عرض بيانات التقرير في الجدول
      let tableContent = '';
      
      if (salesData.length === 0) {
        tableContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد بيانات للفترة المحددة</td>
          </tr>
        `;
      } else {
        salesData.forEach(item => {
          tableContent += `
            <tr>
              <td>${formatReportDate(item.date_group, period)}</td>
              <td>${item.orders_count}</td>
              <td>${formatCurrency(item.total_sales)}</td>
              <td>${formatCurrency(item.total_discounts)}</td>
              <td>${formatCurrency(item.total_taxes)}</td>
              <td>${formatCurrency(item.final_sales)}</td>
            </tr>
          `;
        });
      }
      
      $('#sales-report-table tbody').html(tableContent);
      
      // إنشاء الرسم البياني
      createSalesChart(salesData, period);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل تقرير المبيعات');
      console.error('خطأ في تحميل تقرير المبيعات:', xhr);
    }
  });
}

// تنسيق تاريخ التقرير
function formatReportDate(dateGroup, period) {
  switch (period) {
    case 'daily':
      return new Date(dateGroup).toLocaleDateString('ar-SA');
    case 'weekly':
      const [year, week] = dateGroup.split('-');
      return `الأسبوع ${week} - ${year}`;
    case 'monthly':
      const [yearM, month] = dateGroup.split('-');
      const monthNames = [
        'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
      ];
      return `${monthNames[parseInt(month) - 1]} ${yearM}`;
    case 'yearly':
      return dateGroup;
    default:
      return dateGroup;
  }
}

// إنشاء الرسم البياني للمبيعات
function createSalesChart(salesData, period) {
  const ctx = document.getElementById('sales-chart').getContext('2d');
  
  // تحويل البيانات إلى تنسيق مناسب للرسم البياني
  const labels = salesData.map(item => formatReportDate(item.date_group, period));
  const salesValues = salesData.map(item => item.final_sales);
  const ordersValues = salesData.map(item => item.orders_count);
  
  // إنشاء الرسم البياني
  if (window.salesChart) {
    window.salesChart.destroy();
  }
  
  window.salesChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'المبيعات',
          data: salesValues,
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1,
          yAxisID: 'y'
        },
        {
          label: 'عدد الطلبات',
          data: ordersValues,
          type: 'line',
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 2,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {
            display: true,
            text: 'المبيعات (ر.س)'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: 'عدد الطلبات'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    }
  });
}

// تحميل تقرير المنتجات الأكثر مبيعاً
function loadTopProductsReport(limit = 10, dateFrom = '', dateTo = '') {
  $.ajax({
    url: `/api/reports/top-products?limit=${limit}&dateFrom=${dateFrom}&dateTo=${dateTo}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const products = response.products;
      
      // عرض بيانات التقرير في الجدول
      let tableContent = '';
      
      if (products.length === 0) {
        tableContent = `
          <tr>
            <td colspan="5" class="text-center">لا توجد بيانات للفترة المحددة</td>
          </tr>
        `;
      } else {
        products.forEach((product, index) => {
          tableContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${product.name}</td>
              <td>${product.sku || '-'}</td>
              <td>${product.total_quantity}</td>
              <td>${formatCurrency(product.total_sales)}</td>
            </tr>
          `;
        });
      }
      
      $('#top-products-table tbody').html(tableContent);
      
      // إنشاء الرسم البياني
      createTopProductsChart(products);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل تقرير المنتجات الأكثر مبيعاً');
      console.error('خطأ في تحميل تقرير المنتجات الأكثر مبيعاً:', xhr);
    }
  });
}

// إنشاء الرسم البياني للمنتجات الأكثر مبيعاً
function createTopProductsChart(products) {
  const ctx = document.getElementById('top-products-chart').getContext('2d');
  
  // تحويل البيانات إلى تنسيق مناسب للرسم البياني
  const labels = products.map(product => product.name);
  const quantityValues = products.map(product => product.total_quantity);
  const salesValues = products.map(product => product.total_sales);
  
  // إنشاء الرسم البياني
  if (window.topProductsChart) {
    window.topProductsChart.destroy();
  }
  
  window.topProductsChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'الكمية المباعة',
          data: quantityValues,
          backgroundColor: 'rgba(75, 192, 192, 0.5)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'المنتجات الأكثر مبيعاً'
        }
      }
    }
  });
}

// تحميل تقرير العملاء الأكثر شراءً
function loadTopCustomersReport(limit = 10, dateFrom = '', dateTo = '') {
  $.ajax({
    url: `/api/reports/top-customers?limit=${limit}&dateFrom=${dateFrom}&dateTo=${dateTo}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const customers = response.customers;
      
      // عرض بيانات التقرير في الجدول
      let tableContent = '';
      
      if (customers.length === 0) {
        tableContent = `
          <tr>
            <td colspan="5" class="text-center">لا توجد بيانات للفترة المحددة</td>
          </tr>
        `;
      } else {
        customers.forEach((customer, index) => {
          tableContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${customer.name}</td>
              <td>${customer.phone || '-'}</td>
              <td>${customer.orders_count}</td>
              <td>${formatCurrency(customer.total_spent)}</td>
            </tr>
          `;
        });
      }
      
      $('#top-customers-table tbody').html(tableContent);
      
      // إنشاء الرسم البياني
      createTopCustomersChart(customers);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل تقرير العملاء الأكثر شراءً');
      console.error('خطأ في تحميل تقرير العملاء الأكثر شراءً:', xhr);
    }
  });
}

// إنشاء الرسم البياني للعملاء الأكثر شراءً
function createTopCustomersChart(customers) {
  const ctx = document.getElementById('top-customers-chart').getContext('2d');
  
  // تحويل البيانات إلى تنسيق مناسب للرسم البياني
  const labels = customers.map(customer => customer.name);
  const spentValues = customers.map(customer => customer.total_spent);
  
  // إنشاء الرسم البياني
  if (window.topCustomersChart) {
    window.topCustomersChart.destroy();
  }
  
  window.topCustomersChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: labels,
      datasets: [
        {
          data: spentValues,
          backgroundColor: [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)',
            'rgba(255, 159, 64, 0.7)',
            'rgba(199, 199, 199, 0.7)',
            'rgba(83, 102, 255, 0.7)',
            'rgba(40, 159, 64, 0.7)',
            'rgba(210, 199, 199, 0.7)'
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)',
            'rgba(199, 199, 199, 1)',
            'rgba(83, 102, 255, 1)',
            'rgba(40, 159, 64, 1)',
            'rgba(210, 199, 199, 1)'
          ],
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'right',
        },
        title: {
          display: true,
          text: 'العملاء الأكثر شراءً'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.label || '';
              const value = context.raw || 0;
              return `${label}: ${formatCurrency(value)}`;
            }
          }
        }
      }
    }
  });
}

// تحميل تقرير المخزون
function loadInventoryReport(lowStock = false) {
  $.ajax({
    url: `/api/reports/inventory?lowStock=${lowStock}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const products = response.products;
      const summary = response.summary;
      
      // عرض ملخص التقرير
      $('#total-products').text(summary.totalProducts);
      $('#total-items').text(summary.totalItems);
      $('#low-stock-count').text(summary.lowStockCount);
      $('#out-of-stock-count').text(summary.outOfStockCount);
      
      // عرض بيانات التقرير في الجدول
      let tableContent = '';
      
      if (products.length === 0) {
        tableContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد منتجات</td>
          </tr>
        `;
      } else {
        products.forEach(product => {
          const stockStatus = product.quantity <= product.min_quantity ? 'text-danger' : 'text-success';
          
          tableContent += `
            <tr>
              <td>${product.name}</td>
              <td>${product.sku || '-'}</td>
              <td>${product.category_name || '-'}</td>
              <td class="${stockStatus}">${product.quantity}</td>
              <td>${product.min_quantity}</td>
              <td>${formatCurrency(product.price)}</td>
            </tr>
          `;
        });
      }
      
      $('#inventory-table tbody').html(tableContent);
      
      // إنشاء الرسم البياني
      createInventoryChart(products);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل تقرير المخزون');
      console.error('خطأ في تحميل تقرير المخزون:', xhr);
    }
  });
}

// إنشاء الرسم البياني للمخزون
function createInventoryChart(products) {
  const ctx = document.getElementById('inventory-chart').getContext('2d');
  
  // تجميع البيانات حسب الفئة
  const categories = {};
  products.forEach(product => {
    const category = product.category_name || 'بدون فئة';
    if (!categories[category]) {
      categories[category] = {
        count: 0,
        quantity: 0
      };
    }
    categories[category].count++;
    categories[category].quantity += product.quantity;
  });
  
  // تحويل البيانات إلى تنسيق مناسب للرسم البياني
  const labels = Object.keys(categories);
  const countValues = labels.map(label => categories[label].count);
  const quantityValues = labels.map(label => categories[label].quantity);
  
  // إنشاء الرسم البياني
  if (window.inventoryChart) {
    window.inventoryChart.destroy();
  }
  
  window.inventoryChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'عدد المنتجات',
          data: countValues,
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1,
          yAxisID: 'y'
        },
        {
          label: 'الكمية المتاحة',
          data: quantityValues,
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 1,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {
            display: true,
            text: 'عدد المنتجات'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: 'الكمية المتاحة'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    }
  });
}

// تحميل بيانات لوحة التحكم
function loadDashboardData() {
  $.ajax({
    url: '/api/reports/dashboard',
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      // عرض إحصائيات المبيعات
      $('#today-sales-count').text(response.sales.today.orders_count);
      $('#today-sales-amount').text(formatCurrency(response.sales.today.total_sales));
      $('#monthly-sales-count').text(response.sales.monthly.orders_count);
      $('#monthly-sales-amount').text(formatCurrency(response.sales.monthly.total_sales));
      
      // عرض إحصائيات العملاء والمنتجات
      $('#customers-count').text(response.customers.total);
      $('#products-count').text(response.products.total);
      $('#low-stock-count').text(response.products.lowStock);
      
      // عرض آخر الطلبات
      let ordersContent = '';
      
      if (response.recentOrders && response.recentOrders.length > 0) {
        response.recentOrders.forEach(order => {
          ordersContent += `
            <tr>
              <td>${order.id}</td>
              <td>${order.customer_name || 'عميل غير مسجل'}</td>
              <td>${formatDate(order.order_date)}</td>
              <td>${formatCurrency(order.final_amount)}</td>
              <td>
                <span class="badge ${getOrderStatusClass(order.order_status)}">
                  ${getOrderStatusText(order.order_status)}
                </span>
              </td>
              <td>
                <a href="/sales/${order.id}" class="btn btn-sm btn-info">
                  <i class="fas fa-eye"></i>
                </a>
              </td>
            </tr>
          `;
        });
      } else {
        ordersContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد طلبات حديثة</td>
          </tr>
        `;
      }
      
      $('#recent-orders tbody').html(ordersContent);
      
      // عرض المنتجات الأكثر مبيعاً
      let productsContent = '';
      
      if (response.topProducts && response.topProducts.length > 0) {
        response.topProducts.forEach((product, index) => {
          productsContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${product.name}</td>
              <td>${product.sku || '-'}</td>
              <td>${product.total_quantity}</td>
            </tr>
          `;
        });
      } else {
        productsContent = `
          <tr>
            <td colspan="4" class="text-center">لا توجد بيانات</td>
          </tr>
        `;
      }
      
      $('#top-products tbody').html(productsContent);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل بيانات لوحة التحكم');
      console.error('خطأ في تحميل بيانات لوحة التحكم:', xhr);
    }
  });
}

// تهيئة صفحة التقارير
$(document).ready(function() {
  // التحقق من المسار الحالي
  const path = window.location.pathname;
  
  if (path === '/') {
    // صفحة لوحة التحكم
    loadDashboardData();
    
    // تحديث البيانات كل 5 دقائق
    setInterval(loadDashboardData, 5 * 60 * 1000);
    
  } else if (path === '/reports/sales') {
    // صفحة تقرير المبيعات
    loadSalesReport();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const period = $('#period-select').val();
      const dateFrom = $('#date-from').val();
      const dateTo = $('#date-to').val();
      loadSalesReport(period, dateFrom, dateTo);
    });
    
  } else if (path === '/reports/products') {
    // صفحة تقرير المنتجات الأكثر مبيعاً
    loadTopProductsReport();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const limit = $('#limit-select').val();
      const dateFrom = $('#date-from').val();
      const dateTo = $('#date-to').val();
      loadTopProductsReport(limit, dateFrom, dateTo);
    });
    
  } else if (path === '/reports/customers') {
    // صفحة تقرير العملاء الأكثر شراءً
    loadTopCustomersReport();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const limit = $('#limit-select').val();
      const dateFrom = $('#date-from').val();
      const dateTo = $('#date-to').val();
      loadTopCustomersReport(limit, dateFrom, dateTo);
    });
    
  } else if (path === '/reports/inventory') {
    // صفحة تقرير المخزون
    loadInventoryReport();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const lowStock = $('#low-stock-filter').prop('checked');
      loadInventoryReport(lowStock);
    });
  }
});

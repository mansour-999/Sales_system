/**
 * ملف JavaScript الرئيسي للواجهة الأمامية
 */

// التحقق من تسجيل الدخول
function checkAuth() {
  const token = localStorage.getItem('token');
  if (!token && window.location.pathname !== '/login') {
    window.location.href = '/login';
    return false;
  }
  return true;
}

// إعداد رأس الطلب مع التوكن
function getAuthHeader() {
  const token = localStorage.getItem('token');
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };
}

// تسجيل الخروج
function logout() {
  $.ajax({
    url: '/api/auth/logout',
    type: 'POST',
    headers: getAuthHeader(),
    success: function() {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    },
    error: function() {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
  });
}

// تنسيق التاريخ
function formatDate(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// تنسيق العملة
function formatCurrency(amount) {
  if (amount === undefined || amount === null) return '0.00 ر.س';
  return parseFloat(amount).toFixed(2) + ' ر.س';
}

// عرض رسالة نجاح
function showSuccess(message) {
  const alert = `
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="إغلاق"></button>
    </div>
  `;
  $('#alerts-container').html(alert);
  
  // إخفاء التنبيه بعد 5 ثوانٍ
  setTimeout(() => {
    $('.alert').alert('close');
  }, 5000);
}

// عرض رسالة خطأ
function showError(message) {
  const alert = `
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="إغلاق"></button>
    </div>
  `;
  $('#alerts-container').html(alert);
  
  // إخفاء التنبيه بعد 5 ثوانٍ
  setTimeout(() => {
    $('.alert').alert('close');
  }, 5000);
}

// تحميل بيانات المستخدم في القالب
function loadUserData() {
  const userString = localStorage.getItem('user');
  if (userString) {
    const user = JSON.parse(userString);
    $('#user-name').text(user.fullName || user.username);
    
    // إظهار/إخفاء عناصر القائمة حسب دور المستخدم
    if (user.role === 'admin') {
      $('.admin-only').show();
    } else {
      $('.admin-only').hide();
    }
  }
}

// تهيئة الصفحة
$(document).ready(function() {
  // التحقق من تسجيل الدخول
  if (window.location.pathname !== '/login') {
    if (!checkAuth()) return;
    loadUserData();
  }
  
  // معالجة زر تسجيل الخروج
  $('#logout-btn').on('click', function(e) {
    e.preventDefault();
    logout();
  });
});

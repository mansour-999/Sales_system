/**
 * ملف JavaScript لصفحة المنتجات
 */

// تحميل قائمة المنتجات
function loadProducts(page = 1, limit = 10, search = '') {
  $.ajax({
    url: `/api/products?page=${page}&limit=${limit}&search=${search}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const products = response.products;
      const pagination = response.pagination;
      
      // عرض المنتجات في الجدول
      let tableContent = '';
      
      if (products.length === 0) {
        tableContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد منتجات متاحة</td>
          </tr>
        `;
      } else {
        products.forEach(product => {
          tableContent += `
            <tr>
              <td>
                <img src="${product.image_url || '/images/default-product.png'}" alt="${product.name}" class="product-thumbnail">
              </td>
              <td>${product.name}</td>
              <td>${product.sku || '-'}</td>
              <td>${formatCurrency(product.price)}</td>
              <td>
                <span class="${product.quantity <= product.min_quantity ? 'text-danger' : 'text-success'}">
                  ${product.quantity}
                </span>
              </td>
              <td>
                <div class="btn-group btn-group-sm">
                  <a href="/products/${product.id}" class="btn btn-info">
                    <i class="fas fa-eye"></i>
                  </a>
                  <a href="/products/${product.id}/edit" class="btn btn-primary">
                    <i class="fas fa-edit"></i>
                  </a>
                  <button class="btn btn-danger delete-product" data-id="${product.id}">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }
      
      $('#products-table tbody').html(tableContent);
      
      // إنشاء أزرار الترقيم
      let paginationHtml = '';
      
      if (pagination.totalPages > 1) {
        paginationHtml += `
          <nav aria-label="ترقيم الصفحات">
            <ul class="pagination justify-content-center">
              <li class="page-item ${pagination.currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage - 1}">السابق</a>
              </li>
        `;
        
        for (let i = 1; i <= pagination.totalPages; i++) {
          paginationHtml += `
            <li class="page-item ${pagination.currentPage === i ? 'active' : ''}">
              <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
          `;
        }
        
        paginationHtml += `
              <li class="page-item ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage + 1}">التالي</a>
              </li>
            </ul>
          </nav>
        `;
      }
      
      $('#pagination-container').html(paginationHtml);
      
      // إضافة معالج أحداث لأزرار الترقيم
      $('.pagination .page-link').on('click', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        const search = $('#search-input').val();
        loadProducts(page, limit, search);
      });
      
      // إضافة معالج أحداث لأزرار الحذف
      $('.delete-product').on('click', function() {
        const productId = $(this).data('id');
        deleteProduct(productId);
      });
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل المنتجات');
      console.error('خطأ في تحميل المنتجات:', xhr);
    }
  });
}

// حذف منتج
function deleteProduct(productId) {
  if (confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
    $.ajax({
      url: `/api/products/${productId}`,
      type: 'DELETE',
      headers: getAuthHeader(),
      success: function(response) {
        showSuccess(response.message);
        loadProducts(); // إعادة تحميل المنتجات
      },
      error: function(xhr) {
        showError(xhr.responseJSON?.message || 'حدث خطأ أثناء حذف المنتج');
      }
    });
  }
}

// تحميل تفاصيل منتج
function loadProductDetails(productId) {
  $.ajax({
    url: `/api/products/${productId}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(product) {
      // ملء بيانات المنتج في الصفحة
      $('#product-name').text(product.name);
      $('#product-image').attr('src', product.image_url || '/images/default-product.png');
      $('#product-price').text(formatCurrency(product.price));
      $('#product-sku').text(product.sku || '-');
      $('#product-barcode').text(product.barcode || '-');
      $('#product-category').text(product.category_name || '-');
      $('#product-quantity').text(product.quantity);
      $('#product-min-quantity').text(product.min_quantity);
      $('#product-description').text(product.description || 'لا يوجد وصف');
      
      // تلوين كمية المخزون
      if (product.quantity <= product.min_quantity) {
        $('#product-quantity').addClass('text-danger');
      } else {
        $('#product-quantity').addClass('text-success');
      }
      
      // إضافة معالج أحداث لزر الحذف
      $('#delete-product-btn').data('id', product.id);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل بيانات المنتج');
      console.error('خطأ في تحميل بيانات المنتج:', xhr);
    }
  });
}

// تحميل الفئات
function loadCategories(selectElement) {
  $.ajax({
    url: '/api/products/categories/all',
    type: 'GET',
    headers: getAuthHeader(),
    success: function(categories) {
      let options = '<option value="">-- اختر الفئة --</option>';
      
      categories.forEach(category => {
        options += `<option value="${category.id}">${category.name}</option>`;
      });
      
      $(selectElement).html(options);
    },
    error: function(xhr) {
      console.error('خطأ في تحميل الفئات:', xhr);
    }
  });
}

// تهيئة صفحة المنتجات
$(document).ready(function() {
  // التحقق من المسار الحالي
  const path = window.location.pathname;
  
  if (path === '/products') {
    // صفحة قائمة المنتجات
    loadProducts();
    
    // معالجة البحث
    $('#search-form').on('submit', function(e) {
      e.preventDefault();
      const search = $('#search-input').val();
      loadProducts(1, 10, search);
    });
    
  } else if (path.match(/\/products\/\d+$/)) {
    // صفحة تفاصيل المنتج
    const productId = path.split('/').pop();
    loadProductDetails(productId);
    
    // معالجة زر الحذف
    $('#delete-product-btn').on('click', function() {
      const productId = $(this).data('id');
      deleteProduct(productId);
    });
    
  } else if (path === '/products/new') {
    // صفحة إضافة منتج جديد
    loadCategories('#category-select');
    
    // معالجة نموذج إضافة منتج
    $('#product-form').on('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      
      $.ajax({
        url: '/api/products',
        type: 'POST',
        data: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        processData: false,
        contentType: false,
        success: function(response) {
          showSuccess(response.message);
          window.location.href = `/products/${response.productId}`;
        },
        error: function(xhr) {
          showError(xhr.responseJSON?.message || 'حدث خطأ أثناء إضافة المنتج');
        }
      });
    });
    
  } else if (path.match(/\/products\/\d+\/edit$/)) {
    // صفحة تعديل المنتج
    const productId = path.split('/')[2];
    loadCategories('#category-select');
    
    // تحميل بيانات المنتج
    $.ajax({
      url: `/api/products/${productId}`,
      type: 'GET',
      headers: getAuthHeader(),
      success: function(product) {
        $('#product-name').val(product.name);
        $('#product-sku').val(product.sku || '');
        $('#product-barcode').val(product.barcode || '');
        $('#product-price').val(product.price);
        $('#product-cost-price').val(product.cost_price || '');
        $('#product-quantity').val(product.quantity);
        $('#product-min-quantity').val(product.min_quantity);
        $('#category-select').val(product.category_id || '');
        $('#product-description').val(product.description || '');
        
        if (product.image_url) {
          $('#current-image').attr('src', product.image_url).show();
        }
      },
      error: function(xhr) {
        showError('حدث خطأ أثناء تحميل بيانات المنتج');
        console.error('خطأ في تحميل بيانات المنتج:', xhr);
      }
    });
    
    // معالجة نموذج تعديل المنتج
    $('#product-form').on('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      
      $.ajax({
        url: `/api/products/${productId}`,
        type: 'PUT',
        data: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        processData: false,
        contentType: false,
        success: function(response) {
          showSuccess(response.message);
          window.location.href = `/products/${productId}`;
        },
        error: function(xhr) {
          showError(xhr.responseJSON?.message || 'حدث خطأ أثناء تعديل المنتج');
        }
      });
    });
  }
});

/**
 * ملف JavaScript لصفحة العملاء
 */

// تحميل قائمة العملاء
function loadCustomers(page = 1, limit = 10, search = '') {
  $.ajax({
    url: `/api/customers?page=${page}&limit=${limit}&search=${search}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const customers = response.customers;
      const pagination = response.pagination;
      
      // عرض العملاء في الجدول
      let tableContent = '';
      
      if (customers.length === 0) {
        tableContent = `
          <tr>
            <td colspan="5" class="text-center">لا يوجد عملاء مسجلين</td>
          </tr>
        `;
      } else {
        customers.forEach(customer => {
          tableContent += `
            <tr>
              <td>${customer.name}</td>
              <td>${customer.phone || '-'}</td>
              <td>${customer.email || '-'}</td>
              <td>${formatDate(customer.created_at)}</td>
              <td>
                <div class="btn-group btn-group-sm">
                  <a href="/customers/${customer.id}" class="btn btn-info">
                    <i class="fas fa-eye"></i>
                  </a>
                  <a href="/customers/${customer.id}/edit" class="btn btn-primary">
                    <i class="fas fa-edit"></i>
                  </a>
                  <button class="btn btn-danger delete-customer" data-id="${customer.id}">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }
      
      $('#customers-table tbody').html(tableContent);
      
      // إنشاء أزرار الترقيم
      let paginationHtml = '';
      
      if (pagination.totalPages > 1) {
        paginationHtml += `
          <nav aria-label="ترقيم الصفحات">
            <ul class="pagination justify-content-center">
              <li class="page-item ${pagination.currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage - 1}">السابق</a>
              </li>
        `;
        
        for (let i = 1; i <= pagination.totalPages; i++) {
          paginationHtml += `
            <li class="page-item ${pagination.currentPage === i ? 'active' : ''}">
              <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
          `;
        }
        
        paginationHtml += `
              <li class="page-item ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage + 1}">التالي</a>
              </li>
            </ul>
          </nav>
        `;
      }
      
      $('#pagination-container').html(paginationHtml);
      
      // إضافة معالج أحداث لأزرار الترقيم
      $('.pagination .page-link').on('click', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        const search = $('#search-input').val();
        loadCustomers(page, limit, search);
      });
      
      // إضافة معالج أحداث لأزرار الحذف
      $('.delete-customer').on('click', function() {
        const customerId = $(this).data('id');
        deleteCustomer(customerId);
      });
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل العملاء');
      console.error('خطأ في تحميل العملاء:', xhr);
    }
  });
}

// حذف عميل
function deleteCustomer(customerId) {
  if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
    $.ajax({
      url: `/api/customers/${customerId}`,
      type: 'DELETE',
      headers: getAuthHeader(),
      success: function(response) {
        showSuccess(response.message);
        loadCustomers(); // إعادة تحميل العملاء
      },
      error: function(xhr) {
        showError(xhr.responseJSON?.message || 'حدث خطأ أثناء حذف العميل');
      }
    });
  }
}

// تحميل تفاصيل عميل
function loadCustomerDetails(customerId) {
  $.ajax({
    url: `/api/customers/${customerId}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(customer) {
      // ملء بيانات العميل في الصفحة
      $('#customer-name').text(customer.name);
      $('#customer-phone').text(customer.phone || '-');
      $('#customer-email').text(customer.email || '-');
      $('#customer-address').text(customer.address || '-');
      $('#customer-notes').text(customer.notes || '-');
      $('#customer-created').text(formatDate(customer.created_at));
      $('#customer-total-purchases').text(formatCurrency(customer.total_purchases));
      
      // عرض الطلبات الأخيرة
      let ordersContent = '';
      
      if (customer.recent_orders && customer.recent_orders.length > 0) {
        customer.recent_orders.forEach(order => {
          ordersContent += `
            <tr>
              <td>${order.id}</td>
              <td>${formatDate(order.order_date)}</td>
              <td>${formatCurrency(order.final_amount)}</td>
              <td>
                <span class="badge ${getOrderStatusClass(order.order_status)}">
                  ${getOrderStatusText(order.order_status)}
                </span>
              </td>
              <td>
                <span class="badge ${getPaymentStatusClass(order.payment_status)}">
                  ${getPaymentStatusText(order.payment_status)}
                </span>
              </td>
              <td>
                <a href="/sales/${order.id}" class="btn btn-sm btn-info">
                  <i class="fas fa-eye"></i>
                </a>
              </td>
            </tr>
          `;
        });
      } else {
        ordersContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد طلبات سابقة</td>
          </tr>
        `;
      }
      
      $('#customer-orders tbody').html(ordersContent);
      
      // إضافة معالج أحداث لزر الحذف
      $('#delete-customer-btn').data('id', customer.id);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل بيانات العميل');
      console.error('خطأ في تحميل بيانات العميل:', xhr);
    }
  });
}

// الحصول على نص حالة الطلب
function getOrderStatusText(status) {
  switch (status) {
    case 'new': return 'جديد';
    case 'processing': return 'قيد المعالجة';
    case 'completed': return 'مكتمل';
    case 'cancelled': return 'ملغي';
    default: return status;
  }
}

// الحصول على صنف حالة الطلب
function getOrderStatusClass(status) {
  switch (status) {
    case 'new': return 'bg-info';
    case 'processing': return 'bg-warning';
    case 'completed': return 'bg-success';
    case 'cancelled': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

// الحصول على نص حالة الدفع
function getPaymentStatusText(status) {
  switch (status) {
    case 'pending': return 'معلق';
    case 'paid': return 'مدفوع';
    case 'partially_paid': return 'مدفوع جزئياً';
    case 'cancelled': return 'ملغي';
    default: return status;
  }
}

// الحصول على صنف حالة الدفع
function getPaymentStatusClass(status) {
  switch (status) {
    case 'pending': return 'bg-warning';
    case 'paid': return 'bg-success';
    case 'partially_paid': return 'bg-info';
    case 'cancelled': return 'bg-danger';
    default: return 'bg-secondary';
  }
}

// تهيئة صفحة العملاء
$(document).ready(function() {
  // التحقق من المسار الحالي
  const path = window.location.pathname;
  
  if (path === '/customers') {
    // صفحة قائمة العملاء
    loadCustomers();
    
    // معالجة البحث
    $('#search-form').on('submit', function(e) {
      e.preventDefault();
      const search = $('#search-input').val();
      loadCustomers(1, 10, search);
    });
    
  } else if (path.match(/\/customers\/\d+$/)) {
    // صفحة تفاصيل العميل
    const customerId = path.split('/').pop();
    loadCustomerDetails(customerId);
    
    // معالجة زر الحذف
    $('#delete-customer-btn').on('click', function() {
      const customerId = $(this).data('id');
      deleteCustomer(customerId);
    });
    
  } else if (path === '/customers/new') {
    // صفحة إضافة عميل جديد
    
    // معالجة نموذج إضافة عميل
    $('#customer-form').on('submit', function(e) {
      e.preventDefault();
      
      const formData = {
        name: $('#customer-name').val(),
        phone: $('#customer-phone').val(),
        email: $('#customer-email').val(),
        address: $('#customer-address').val(),
        notes: $('#customer-notes').val()
      };
      
      $.ajax({
        url: '/api/customers',
        type: 'POST',
        data: JSON.stringify(formData),
        headers: getAuthHeader(),
        contentType: 'application/json',
        success: function(response) {
          showSuccess(response.message);
          window.location.href = `/customers/${response.customerId}`;
        },
        error: function(xhr) {
          showError(xhr.responseJSON?.message || 'حدث خطأ أثناء إضافة العميل');
        }
      });
    });
    
  } else if (path.match(/\/customers\/\d+\/edit$/)) {
    // صفحة تعديل العميل
    const customerId = path.split('/')[2];
    
    // تحميل بيانات العميل
    $.ajax({
      url: `/api/customers/${customerId}`,
      type: 'GET',
      headers: getAuthHeader(),
      success: function(customer) {
        $('#customer-name').val(customer.name);
        $('#customer-phone').val(customer.phone || '');
        $('#customer-email').val(customer.email || '');
        $('#customer-address').val(customer.address || '');
        $('#customer-notes').val(customer.notes || '');
      },
      error: function(xhr) {
        showError('حدث خطأ أثناء تحميل بيانات العميل');
        console.error('خطأ في تحميل بيانات العميل:', xhr);
      }
    });
    
    // معالجة نموذج تعديل العميل
    $('#customer-form').on('submit', function(e) {
      e.preventDefault();
      
      const formData = {
        name: $('#customer-name').val(),
        phone: $('#customer-phone').val(),
        email: $('#customer-email').val(),
        address: $('#customer-address').val(),
        notes: $('#customer-notes').val()
      };
      
      $.ajax({
        url: `/api/customers/${customerId}`,
        type: 'PUT',
        data: JSON.stringify(formData),
        headers: getAuthHeader(),
        contentType: 'application/json',
        success: function(response) {
          showSuccess(response.message);
          window.location.href = `/customers/${customerId}`;
        },
        error: function(xhr) {
          showError(xhr.responseJSON?.message || 'حدث خطأ أثناء تعديل العميل');
        }
      });
    });
  }
});

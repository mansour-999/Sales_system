/**
 * ملف JavaScript لصفحة المبيعات والطلبات
 */

// تحميل قائمة الطلبات
function loadOrders(page = 1, limit = 10, status = '', dateFrom = '', dateTo = '') {
  $.ajax({
    url: `/api/orders?page=${page}&limit=${limit}&status=${status}&dateFrom=${dateFrom}&dateTo=${dateTo}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const orders = response.orders;
      const pagination = response.pagination;
      
      // عرض الطلبات في الجدول
      let tableContent = '';
      
      if (orders.length === 0) {
        tableContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد طلبات مسجلة</td>
          </tr>
        `;
      } else {
        orders.forEach(order => {
          tableContent += `
            <tr>
              <td>${order.id}</td>
              <td>${order.customer_name || 'عميل غير مسجل'}</td>
              <td>${formatDate(order.order_date)}</td>
              <td>${formatCurrency(order.final_amount)}</td>
              <td>
                <span class="badge ${getOrderStatusClass(order.order_status)}">
                  ${getOrderStatusText(order.order_status)}
                </span>
              </td>
              <td>
                <span class="badge ${getPaymentStatusClass(order.payment_status)}">
                  ${getPaymentStatusText(order.payment_status)}
                </span>
              </td>
              <td>
                <div class="btn-group btn-group-sm">
                  <a href="/sales/${order.id}" class="btn btn-info">
                    <i class="fas fa-eye"></i>
                  </a>
                  <button class="btn btn-danger cancel-order" data-id="${order.id}" ${order.order_status === 'completed' || order.order_status === 'cancelled' ? 'disabled' : ''}>
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }
      
      $('#orders-table tbody').html(tableContent);
      
      // إنشاء أزرار الترقيم
      let paginationHtml = '';
      
      if (pagination.totalPages > 1) {
        paginationHtml += `
          <nav aria-label="ترقيم الصفحات">
            <ul class="pagination justify-content-center">
              <li class="page-item ${pagination.currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage - 1}">السابق</a>
              </li>
        `;
        
        for (let i = 1; i <= pagination.totalPages; i++) {
          paginationHtml += `
            <li class="page-item ${pagination.currentPage === i ? 'active' : ''}">
              <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
          `;
        }
        
        paginationHtml += `
              <li class="page-item ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage + 1}">التالي</a>
              </li>
            </ul>
          </nav>
        `;
      }
      
      $('#pagination-container').html(paginationHtml);
      
      // إضافة معالج أحداث لأزرار الترقيم
      $('.pagination .page-link').on('click', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        loadOrders(page, limit, status, dateFrom, dateTo);
      });
      
      // إضافة معالج أحداث لأزرار إلغاء الطلب
      $('.cancel-order').on('click', function() {
        const orderId = $(this).data('id');
        cancelOrder(orderId);
      });
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل الطلبات');
      console.error('خطأ في تحميل الطلبات:', xhr);
    }
  });
}

// إلغاء طلب
function cancelOrder(orderId) {
  if (confirm('هل أنت متأكد من إلغاء هذا الطلب؟ سيتم إعادة المنتجات للمخزون.')) {
    $.ajax({
      url: `/api/orders/${orderId}`,
      type: 'DELETE',
      headers: getAuthHeader(),
      success: function(response) {
        showSuccess(response.message);
        loadOrders(); // إعادة تحميل الطلبات
      },
      error: function(xhr) {
        showError(xhr.responseJSON?.message || 'حدث خطأ أثناء إلغاء الطلب');
      }
    });
  }
}

// تحميل تفاصيل طلب
function loadOrderDetails(orderId) {
  $.ajax({
    url: `/api/orders/${orderId}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(order) {
      // ملء بيانات الطلب في الصفحة
      $('#order-id').text(order.id);
      $('#order-date').text(formatDate(order.order_date));
      $('#order-customer').text(order.customer_name || 'عميل غير مسجل');
      $('#order-status').html(`
        <span class="badge ${getOrderStatusClass(order.order_status)}">
          ${getOrderStatusText(order.order_status)}
        </span>
      `);
      $('#order-payment-status').html(`
        <span class="badge ${getPaymentStatusClass(order.payment_status)}">
          ${getPaymentStatusText(order.payment_status)}
        </span>
      `);
      $('#order-total').text(formatCurrency(order.total_amount));
      $('#order-discount').text(formatCurrency(order.discount_amount));
      $('#order-tax').text(formatCurrency(order.tax_amount));
      $('#order-final').text(formatCurrency(order.final_amount));
      $('#order-notes').text(order.notes || '-');
      
      // عرض تفاصيل الطلب
      let detailsContent = '';
      
      if (order.details && order.details.length > 0) {
        order.details.forEach((item, index) => {
          detailsContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${item.product_name}</td>
              <td>${item.quantity}</td>
              <td>${formatCurrency(item.unit_price)}</td>
              <td>${item.discount_percent}%</td>
              <td>${formatCurrency(item.total_price)}</td>
            </tr>
          `;
        });
      } else {
        detailsContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد تفاصيل للطلب</td>
          </tr>
        `;
      }
      
      $('#order-details tbody').html(detailsContent);
      
      // عرض معلومات الفاتورة
      if (order.invoice) {
        $('#invoice-number').text(order.invoice.invoice_number);
        $('#invoice-date').text(formatDate(order.invoice.invoice_date));
        $('#invoice-payment-method').text(order.invoice.payment_method || '-');
        
        // تفعيل زر طباعة الفاتورة
        $('#print-invoice-btn').data('id', order.invoice.id).show();
      } else {
        $('#invoice-info').hide();
        $('#print-invoice-btn').hide();
      }
      
      // إضافة معالج أحداث لزر إلغاء الطلب
      $('#cancel-order-btn').data('id', order.id);
      
      // تعطيل زر الإلغاء إذا كان الطلب مكتمل أو ملغي بالفعل
      if (order.order_status === 'completed' || order.order_status === 'cancelled') {
        $('#cancel-order-btn').prop('disabled', true);
      } else {
        $('#cancel-order-btn').prop('disabled', false);
      }
      
      // إضافة معالج أحداث لزر تحديث حالة الطلب
      $('#update-status-btn').data('id', order.id);
      $('#status-select').val(order.order_status);
      
      // إضافة معالج أحداث لزر تحديث حالة الدفع
      $('#update-payment-btn').data('id', order.id);
      $('#payment-status-select').val(order.payment_status);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل بيانات الطلب');
      console.error('خطأ في تحميل بيانات الطلب:', xhr);
    }
  });
}

// تحميل المنتجات للبيع
function loadProductsForSale() {
  $.ajax({
    url: '/api/products?limit=100',
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const products = response.products;
      
      // إنشاء قائمة المنتجات
      let productsHtml = '';
      
      products.forEach(product => {
        if (product.quantity > 0) {
          productsHtml += `
            <div class="col-md-4 col-lg-3 mb-3">
              <div class="card product-card h-100">
                <img src="${product.image_url || '/images/default-product.png'}" class="card-img-top" alt="${product.name}">
                <div class="card-body">
                  <h5 class="card-title">${product.name}</h5>
                  <p class="card-text text-muted">${product.sku || ''}</p>
                  <p class="card-text">السعر: ${formatCurrency(product.price)}</p>
                  <p class="card-text">المتاح: ${product.quantity}</p>
                  <button class="btn btn-primary add-to-cart" 
                    data-id="${product.id}" 
                    data-name="${product.name}" 
                    data-price="${product.price}" 
                    data-max="${product.quantity}">
                    <i class="fas fa-cart-plus"></i> إضافة
                  </button>
                </div>
              </div>
            </div>
          `;
        }
      });
      
      $('#products-container').html(productsHtml);
      
      // إضافة معالج أحداث لأزرار إضافة للسلة
      $('.add-to-cart').on('click', function() {
        const productId = $(this).data('id');
        const productName = $(this).data('name');
        const productPrice = $(this).data('price');
        const maxQuantity = $(this).data('max');
        
        addToCart(productId, productName, productPrice, maxQuantity);
      });
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل المنتجات');
      console.error('خطأ في تحميل المنتجات:', xhr);
    }
  });
}

// إضافة منتج للسلة
function addToCart(productId, productName, productPrice, maxQuantity) {
  // التحقق من وجود المنتج في السلة
  let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  let existingItem = cartItems.find(item => item.productId === productId);
  
  if (existingItem) {
    // زيادة الكمية إذا كان المنتج موجود بالفعل
    if (existingItem.quantity < maxQuantity) {
      existingItem.quantity++;
      existingItem.totalPrice = existingItem.quantity * existingItem.unitPrice;
    } else {
      showError(`لا يمكن إضافة المزيد من هذا المنتج. الكمية المتاحة: ${maxQuantity}`);
      return;
    }
  } else {
    // إضافة منتج جديد للسلة
    cartItems.push({
      productId,
      productName,
      unitPrice: productPrice,
      quantity: 1,
      totalPrice: productPrice,
      maxQuantity
    });
  }
  
  // حفظ السلة في التخزين المحلي
  localStorage.setItem('cartItems', JSON.stringify(cartItems));
  
  // تحديث عرض السلة
  updateCartDisplay();
  
  showSuccess(`تمت إضافة ${productName} إلى السلة`);
}

// تحديث عرض السلة
function updateCartDisplay() {
  const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
  // تحديث عدد العناصر في السلة
  $('#cart-count').text(cartItems.length);
  
  // عرض عناصر السلة
  let cartContent = '';
  let totalAmount = 0;
  
  if (cartItems.length === 0) {
    cartContent = `
      <tr>
        <td colspan="5" class="text-center">السلة فارغة</td>
      </tr>
    `;
    $('#checkout-btn').prop('disabled', true);
  } else {
    cartItems.forEach((item, index) => {
      cartContent += `
        <tr>
          <td>${item.productName}</td>
          <td>${formatCurrency(item.unitPrice)}</td>
          <td>
            <div class="input-group input-group-sm">
              <button class="btn btn-outline-secondary decrease-quantity" data-index="${index}">-</button>
              <input type="text" class="form-control text-center item-quantity" value="${item.quantity}" readonly>
              <button class="btn btn-outline-secondary increase-quantity" data-index="${index}" ${item.quantity >= item.maxQuantity ? 'disabled' : ''}>+</button>
            </div>
          </td>
          <td>${formatCurrency(item.totalPrice)}</td>
          <td>
            <button class="btn btn-sm btn-danger remove-item" data-index="${index}">
              <i class="fas fa-trash"></i>
            </button>
          </td>
        </tr>
      `;
      
      totalAmount += item.totalPrice;
    });
    
    $('#checkout-btn').prop('disabled', false);
  }
  
  $('#cart-items').html(cartContent);
  $('#cart-total').text(formatCurrency(totalAmount));
  
  // إضافة معالج أحداث لأزرار السلة
  $('.decrease-quantity').on('click', function() {
    const index = $(this).data('index');
    decreaseQuantity(index);
  });
  
  $('.increase-quantity').on('click', function() {
    const index = $(this).data('index');
    increaseQuantity(index);
  });
  
  $('.remove-item').on('click', function() {
    const index = $(this).data('index');
    removeCartItem(index);
  });
}

// زيادة كمية منتج في السلة
function increaseQuantity(index) {
  let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
  if (cartItems[index].quantity < cartItems[index].maxQuantity) {
    cartItems[index].quantity++;
    cartItems[index].totalPrice = cartItems[index].quantity * cartItems[index].unitPrice;
    
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartDisplay();
  }
}

// تقليل كمية منتج في السلة
function decreaseQuantity(index) {
  let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
  if (cartItems[index].quantity > 1) {
    cartItems[index].quantity--;
    cartItems[index].totalPrice = cartItems[index].quantity * cartItems[index].unitPrice;
    
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartDisplay();
  } else {
    removeCartItem(index);
  }
}

// حذف منتج من السلة
function removeCartItem(index) {
  let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
  cartItems.splice(index, 1);
  
  localStorage.setItem('cartItems', JSON.stringify(cartItems));
  updateCartDisplay();
}

// البحث عن العملاء
function searchCustomers(query) {
  $.ajax({
    url: `/api/customers/search/query?q=${query}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const customers = response.customers;
      
      let resultsHtml = '';
      
      if (customers.length === 0) {
        resultsHtml = '<p class="text-muted">لا توجد نتائج</p>';
      } else {
        customers.forEach(customer => {
          resultsHtml += `
            <div class="customer-result" data-id="${customer.id}" data-name="${customer.name}">
              <strong>${customer.name}</strong>
              <small>${customer.phone || ''}</small>
            </div>
          `;
        });
      }
      
      $('#customer-search-results').html(resultsHtml).show();
      
      // إضافة معالج أحداث لنتائج البحث
      $('.customer-result').on('click', function() {
        const customerId = $(this).data('id');
        const customerName = $(this).data('name');
        
        $('#customer-id').val(customerId);
        $('#customer-name-display').text(customerName).show();
        $('#customer-search').val('');
        $('#customer-search-results').hide();
      });
    },
    error: function(xhr) {
      console.error('خطأ في البحث عن العملاء:', xhr);
    }
  });
}

// إنشاء طلب جديد
function createOrder() {
  const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
  if (cartItems.length === 0) {
    showError('لا يمكن إنشاء طلب فارغ');
    return;
  }
  
  const customerId = $('#customer-id').val() || null;
  const discountAmount = parseFloat($('#discount-amount').val()) || 0;
  const taxAmount = parseFloat($('#tax-amount').val()) || 0;
  const notes = $('#order-notes').val() || '';
  
  // تحويل عناصر السلة إلى تنسيق مناسب للـ API
  const items = cartItems.map(item => ({
    product_id: item.productId,
    quantity: item.quantity,
    unit_price: item.unitPrice
  }));
  
  // إرسال الطلب
  $.ajax({
    url: '/api/orders',
    type: 'POST',
    data: JSON.stringify({
      customer_id: customerId,
      items,
      discount_amount: discountAmount,
      tax_amount: taxAmount,
      notes
    }),
    headers: getAuthHeader(),
    contentType: 'application/json',
    success: function(response) {
      showSuccess(response.message);
      
      // مسح السلة
      localStorage.removeItem('cartItems');
      
      // الانتقال إلى صفحة الفاتورة
      window.location.href = `/sales/${response.orderId}`;
    },
    error: function(xhr) {
      showError(xhr.responseJSON?.message || 'حدث خطأ أثناء إنشاء الطلب');
    }
  });
}

// تحديث حالة الطلب
function updateOrderStatus(orderId, status) {
  $.ajax({
    url: `/api/orders/${orderId}/status`,
    type: 'PUT',
    data: JSON.stringify({ status }),
    headers: getAuthHeader(),
    contentType: 'application/json',
    success: function(response) {
      showSuccess(response.message);
      loadOrderDetails(orderId); // إعادة تحميل تفاصيل الطلب
    },
    error: function(xhr) {
      showError(xhr.responseJSON?.message || 'حدث خطأ أثناء تحديث حالة الطلب');
    }
  });
}

// تحديث حالة الدفع
function updatePaymentStatus(orderId, paymentStatus, paymentMethod) {
  $.ajax({
    url: `/api/orders/${orderId}/payment`,
    type: 'PUT',
    data: JSON.stringify({ 
      payment_status: paymentStatus,
      payment_method: paymentMethod
    }),
    headers: getAuthHeader(),
    contentType: 'application/json',
    success: function(response) {
      showSuccess(response.message);
      loadOrderDetails(orderId); // إعادة تحميل تفاصيل الطلب
    },
    error: function(xhr) {
      showError(xhr.responseJSON?.message || 'حدث خطأ أثناء تحديث حالة الدفع');
    }
  });
}

// تهيئة صفحة المبيعات
$(document).ready(function() {
  // التحقق من المسار الحالي
  const path = window.location.pathname;
  
  if (path === '/sales') {
    // صفحة قائمة الطلبات
    loadOrders();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const status = $('#status-filter').val();
      const dateFrom = $('#date-from').val();
      const dateTo = $('#date-to').val();
      loadOrders(1, 10, status, dateFrom, dateTo);
    });
    
  } else if (path.match(/\/sales\/\d+$/)) {
    // صفحة تفاصيل الطلب
    const orderId = path.split('/').pop();
    loadOrderDetails(orderId);
    
    // معالجة زر إلغاء الطلب
    $('#cancel-order-btn').on('click', function() {
      const orderId = $(this).data('id');
      cancelOrder(orderId);
    });
    
    // معالجة زر تحديث حالة الطلب
    $('#update-status-form').on('submit', function(e) {
      e.preventDefault();
      const orderId = $('#update-status-btn').data('id');
      const status = $('#status-select').val();
      updateOrderStatus(orderId, status);
    });
    
    // معالجة زر تحديث حالة الدفع
    $('#update-payment-form').on('submit', function(e) {
      e.preventDefault();
      const orderId = $('#update-payment-btn').data('id');
      const paymentStatus = $('#payment-status-select').val();
      const paymentMethod = $('#payment-method-select').val();
      updatePaymentStatus(orderId, paymentStatus, paymentMethod);
    });
    
    // معالجة زر طباعة الفاتورة
    $('#print-invoice-btn').on('click', function() {
      const invoiceId = $(this).data('id');
      window.open(`/api/invoices/${invoiceId}/pdf`, '_blank');
    });
    
  } else if (path === '/sales/new') {
    // صفحة إنشاء طلب جديد
    loadProductsForSale();
    updateCartDisplay();
    
    // معالجة البحث عن العملاء
    $('#customer-search').on('input', function() {
      const query = $(this).val();
      
      if (query.length >= 2) {
        searchCustomers(query);
      } else {
        $('#customer-search-results').hide();
      }
    });
    
    // معالجة زر إلغاء اختيار العميل
    $('#clear-customer-btn').on('click', function() {
      $('#customer-id').val('');
      $('#customer-name-display').text('').hide();
    });
    
    // معالجة زر إنشاء الطلب
    $('#checkout-btn').on('click', function() {
      createOrder();
    });
    
    // معالجة زر مسح السلة
    $('#clear-cart-btn').on('click', function() {
      if (confirm('هل أنت متأكد من مسح جميع المنتجات من السلة؟')) {
        localStorage.removeItem('cartItems');
        updateCartDisplay();
      }
    });
    
    // تحديث إجمالي الطلب عند تغيير الخصم أو الضريبة
    $('#discount-amount, #tax-amount').on('input', function() {
      const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
      let subtotal = 0;
      
      cartItems.forEach(item => {
        subtotal += item.totalPrice;
      });
      
      const discountAmount = parseFloat($('#discount-amount').val()) || 0;
      const taxAmount = parseFloat($('#tax-amount').val()) || 0;
      const total = subtotal - discountAmount + taxAmount;
      
      $('#subtotal-amount').text(formatCurrency(subtotal));
      $('#total-amount').text(formatCurrency(total));
    });
  }
});

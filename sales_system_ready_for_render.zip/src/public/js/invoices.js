/**
 * ملف JavaScript لصفحة الفواتير
 */

// تحميل قائمة الفواتير
function loadInvoices(page = 1, limit = 10, status = '', dateFrom = '', dateTo = '') {
  $.ajax({
    url: `/api/invoices?page=${page}&limit=${limit}&status=${status}&dateFrom=${dateFrom}&dateTo=${dateTo}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(response) {
      const invoices = response.invoices;
      const pagination = response.pagination;
      
      // عرض الفواتير في الجدول
      let tableContent = '';
      
      if (invoices.length === 0) {
        tableContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد فواتير مسجلة</td>
          </tr>
        `;
      } else {
        invoices.forEach(invoice => {
          tableContent += `
            <tr>
              <td>${invoice.invoice_number}</td>
              <td>${invoice.customer_name || 'عميل غير مسجل'}</td>
              <td>${formatDate(invoice.invoice_date)}</td>
              <td>${formatCurrency(invoice.final_amount)}</td>
              <td>
                <span class="badge ${getPaymentStatusClass(invoice.payment_status)}">
                  ${getPaymentStatusText(invoice.payment_status)}
                </span>
              </td>
              <td>
                <div class="btn-group btn-group-sm">
                  <a href="/invoices/${invoice.id}" class="btn btn-info">
                    <i class="fas fa-eye"></i>
                  </a>
                  <button class="btn btn-primary print-invoice" data-id="${invoice.id}">
                    <i class="fas fa-print"></i>
                  </button>
                  <button class="btn btn-secondary email-invoice" data-id="${invoice.id}">
                    <i class="fas fa-envelope"></i>
                  </button>
                </div>
              </td>
            </tr>
          `;
        });
      }
      
      $('#invoices-table tbody').html(tableContent);
      
      // إنشاء أزرار الترقيم
      let paginationHtml = '';
      
      if (pagination.totalPages > 1) {
        paginationHtml += `
          <nav aria-label="ترقيم الصفحات">
            <ul class="pagination justify-content-center">
              <li class="page-item ${pagination.currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage - 1}">السابق</a>
              </li>
        `;
        
        for (let i = 1; i <= pagination.totalPages; i++) {
          paginationHtml += `
            <li class="page-item ${pagination.currentPage === i ? 'active' : ''}">
              <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
          `;
        }
        
        paginationHtml += `
              <li class="page-item ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${pagination.currentPage + 1}">التالي</a>
              </li>
            </ul>
          </nav>
        `;
      }
      
      $('#pagination-container').html(paginationHtml);
      
      // إضافة معالج أحداث لأزرار الترقيم
      $('.pagination .page-link').on('click', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        loadInvoices(page, limit, status, dateFrom, dateTo);
      });
      
      // إضافة معالج أحداث لأزرار طباعة الفاتورة
      $('.print-invoice').on('click', function() {
        const invoiceId = $(this).data('id');
        window.open(`/api/invoices/${invoiceId}/pdf`, '_blank');
      });
      
      // إضافة معالج أحداث لأزرار إرسال الفاتورة بالبريد
      $('.email-invoice').on('click', function() {
        const invoiceId = $(this).data('id');
        showEmailInvoiceModal(invoiceId);
      });
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل الفواتير');
      console.error('خطأ في تحميل الفواتير:', xhr);
    }
  });
}

// عرض نافذة إرسال الفاتورة بالبريد
function showEmailInvoiceModal(invoiceId) {
  $('#email-invoice-id').val(invoiceId);
  $('#email-invoice-modal').modal('show');
}

// إرسال الفاتورة بالبريد
function sendInvoiceByEmail(invoiceId, email) {
  $.ajax({
    url: `/api/invoices/${invoiceId}/email`,
    type: 'POST',
    data: JSON.stringify({ email }),
    headers: getAuthHeader(),
    contentType: 'application/json',
    success: function(response) {
      showSuccess(response.message);
      $('#email-invoice-modal').modal('hide');
    },
    error: function(xhr) {
      showError(xhr.responseJSON?.message || 'حدث خطأ أثناء إرسال الفاتورة');
    }
  });
}

// تحميل تفاصيل فاتورة
function loadInvoiceDetails(invoiceId) {
  $.ajax({
    url: `/api/invoices/${invoiceId}`,
    type: 'GET',
    headers: getAuthHeader(),
    success: function(invoice) {
      // ملء بيانات الفاتورة في الصفحة
      $('#invoice-number').text(invoice.invoice_number);
      $('#invoice-date').text(formatDate(invoice.invoice_date));
      $('#invoice-customer').text(invoice.customer_name || 'عميل غير مسجل');
      $('#invoice-payment-status').html(`
        <span class="badge ${getPaymentStatusClass(invoice.payment_status)}">
          ${getPaymentStatusText(invoice.payment_status)}
        </span>
      `);
      $('#invoice-payment-method').text(invoice.payment_method || '-');
      $('#invoice-total').text(formatCurrency(invoice.total_amount));
      $('#invoice-discount').text(formatCurrency(invoice.discount_amount));
      $('#invoice-tax').text(formatCurrency(invoice.tax_amount));
      $('#invoice-final').text(formatCurrency(invoice.final_amount));
      
      // عرض تفاصيل الفاتورة
      let detailsContent = '';
      
      if (invoice.details && invoice.details.length > 0) {
        invoice.details.forEach((item, index) => {
          detailsContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${item.product_name}</td>
              <td>${item.quantity}</td>
              <td>${formatCurrency(item.unit_price)}</td>
              <td>${item.discount_percent}%</td>
              <td>${formatCurrency(item.total_price)}</td>
            </tr>
          `;
        });
      } else {
        detailsContent = `
          <tr>
            <td colspan="6" class="text-center">لا توجد تفاصيل للفاتورة</td>
          </tr>
        `;
      }
      
      $('#invoice-details tbody').html(detailsContent);
      
      // إضافة معالج أحداث لزر تحديث حالة الدفع
      $('#update-payment-btn').data('id', invoice.id);
      $('#payment-status-select').val(invoice.payment_status);
      $('#payment-method-select').val(invoice.payment_method || '');
      
      // إضافة معالج أحداث لزر طباعة الفاتورة
      $('#print-invoice-btn').data('id', invoice.id);
      
      // إضافة معالج أحداث لزر إرسال الفاتورة بالبريد
      $('#email-invoice-btn').data('id', invoice.id);
    },
    error: function(xhr) {
      showError('حدث خطأ أثناء تحميل بيانات الفاتورة');
      console.error('خطأ في تحميل بيانات الفاتورة:', xhr);
    }
  });
}

// تحديث حالة الدفع للفاتورة
function updateInvoicePayment(invoiceId, paymentStatus, paymentMethod) {
  $.ajax({
    url: `/api/invoices/${invoiceId}/payment`,
    type: 'PUT',
    data: JSON.stringify({ 
      payment_status: paymentStatus,
      payment_method: paymentMethod
    }),
    headers: getAuthHeader(),
    contentType: 'application/json',
    success: function(response) {
      showSuccess(response.message);
      loadInvoiceDetails(invoiceId); // إعادة تحميل تفاصيل الفاتورة
    },
    error: function(xhr) {
      showError(xhr.responseJSON?.message || 'حدث خطأ أثناء تحديث حالة الدفع');
    }
  });
}

// تهيئة صفحة الفواتير
$(document).ready(function() {
  // التحقق من المسار الحالي
  const path = window.location.pathname;
  
  if (path === '/invoices') {
    // صفحة قائمة الفواتير
    loadInvoices();
    
    // معالجة نموذج التصفية
    $('#filter-form').on('submit', function(e) {
      e.preventDefault();
      const status = $('#status-filter').val();
      const dateFrom = $('#date-from').val();
      const dateTo = $('#date-to').val();
      loadInvoices(1, 10, status, dateFrom, dateTo);
    });
    
    // معالجة نموذج إرسال الفاتورة بالبريد
    $('#email-invoice-form').on('submit', function(e) {
      e.preventDefault();
      const invoiceId = $('#email-invoice-id').val();
      const email = $('#email-address').val();
      sendInvoiceByEmail(invoiceId, email);
    });
    
  } else if (path.match(/\/invoices\/\d+$/)) {
    // صفحة تفاصيل الفاتورة
    const invoiceId = path.split('/').pop();
    loadInvoiceDetails(invoiceId);
    
    // معالجة زر تحديث حالة الدفع
    $('#update-payment-form').on('submit', function(e) {
      e.preventDefault();
      const invoiceId = $('#update-payment-btn').data('id');
      const paymentStatus = $('#payment-status-select').val();
      const paymentMethod = $('#payment-method-select').val();
      updateInvoicePayment(invoiceId, paymentStatus, paymentMethod);
    });
    
    // معالجة زر طباعة الفاتورة
    $('#print-invoice-btn').on('click', function() {
      const invoiceId = $(this).data('id');
      window.open(`/api/invoices/${invoiceId}/pdf`, '_blank');
    });
    
    // معالجة زر إرسال الفاتورة بالبريد
    $('#email-invoice-btn').on('click', function() {
      const invoiceId = $(this).data('id');
      showEmailInvoiceModal(invoiceId);
    });
    
    // معالجة نموذج إرسال الفاتورة بالبريد
    $('#email-invoice-form').on('submit', function(e) {
      e.preventDefault();
      const invoiceId = $('#email-invoice-id').val();
      const email = $('#email-address').val();
      sendInvoiceByEmail(invoiceId, email);
    });
  }
});

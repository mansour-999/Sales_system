const fs = require('fs');
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require('cors');
const dotenv = require('dotenv');

// تحميل متغيرات البيئة
dotenv.config();

// تهيئة التطبيق
const app = express();

// تكوين محرك العرض
app.set('views', path.join(__dirname, 'views'));
// التحقق من وجود مجلد views في المسار الحالي، وإلا استخدام المسار البديل
if (!fs.existsSync(path.join(__dirname, 'views'))) {
  app.set('views', path.join(__dirname, '..', 'views'));
}
app.set('view engine', 'ejs');

// الوسائط (Middleware)
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());

// تكوين المجلد العام
app.use(express.static(path.join(__dirname, 'public')));
// التحقق من وجود مجلد public في المسار الحالي، وإلا استخدام المسار البديل
if (!fs.existsSync(path.join(__dirname, 'public'))) {
  app.use(express.static(path.join(__dirname, '..', 'public')));
}

// تحميل المسارات
require('./routes')(app);

// معالجة الأخطاء
app.use(function(req, res, next) {
  res.status(404).render('error', {
    message: 'الصفحة غير موجودة',
    error: { status: 404 }
  });
});

app.use(function(err, req, res, next) {
  res.status(err.status || 500).render('error', {
    message: err.message,
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

module.exports = app;

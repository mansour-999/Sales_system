/**
 * مسارات الطلبات والمبيعات
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * الحصول على جميع الطلبات
 * GET /api/orders
 */
router.get('/', authenticate, (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const status = req.query.status || '';
  const dateFrom = req.query.dateFrom || '';
  const dateTo = req.query.dateTo || '';
  
  let query = `
    SELECT o.*, c.name as customer_name, u.username as user_name
    FROM orders o
    LEFT JOIN customers c ON o.customer_id = c.id
    LEFT JOIN users u ON o.user_id = u.id
    WHERE 1=1
  `;
  
  const params = [];
  
  if (status) {
    query += ` AND o.order_status = ?`;
    params.push(status);
  }
  
  if (dateFrom) {
    query += ` AND o.order_date >= ?`;
    params.push(dateFrom);
  }
  
  if (dateTo) {
    query += ` AND o.order_date <= ?`;
    params.push(dateTo);
  }
  
  query += ` ORDER BY o.order_date DESC LIMIT ? OFFSET ?`;
  params.push(limit, offset);
  
  // الحصول على إجمالي عدد الطلبات للترقيم
  let countQuery = `
    SELECT COUNT(*) as total
    FROM orders o
    WHERE 1=1
  `;
  
  const countParams = [];
  
  if (status) {
    countQuery += ` AND o.order_status = ?`;
    countParams.push(status);
  }
  
  if (dateFrom) {
    countQuery += ` AND o.order_date >= ?`;
    countParams.push(dateFrom);
  }
  
  if (dateTo) {
    countQuery += ` AND o.order_date <= ?`;
    countParams.push(dateTo);
  }
  
  db.get(countQuery, countParams, (err, countResult) => {
    if (err) {
      console.error('خطأ في الحصول على عدد الطلبات:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب الطلبات' });
    }
    
    const total = countResult.total;
    const totalPages = Math.ceil(total / limit);
    
    db.all(query, params, (err, orders) => {
      if (err) {
        console.error('خطأ في الحصول على الطلبات:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب الطلبات' });
      }
      
      res.json({
        orders,
        pagination: {
          total,
          totalPages,
          currentPage: page,
          limit
        }
      });
    });
  });
});

/**
 * الحصول على طلب محدد
 * GET /api/orders/:id
 */
router.get('/:id', authenticate, (req, res) => {
  const orderId = req.params.id;
  
  db.get(`
    SELECT o.*, c.name as customer_name, c.phone as customer_phone, c.email as customer_email,
           u.username as user_name, u.full_name as user_full_name
    FROM orders o
    LEFT JOIN customers c ON o.customer_id = c.id
    LEFT JOIN users u ON o.user_id = u.id
    WHERE o.id = ?
  `, [orderId], (err, order) => {
    if (err) {
      console.error('خطأ في الحصول على الطلب:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب الطلب' });
    }
    
    if (!order) {
      return res.status(404).json({ message: 'الطلب غير موجود' });
    }
    
    // الحصول على تفاصيل الطلب
    db.all(`
      SELECT od.*, p.name as product_name, p.sku as product_sku
      FROM order_details od
      LEFT JOIN products p ON od.product_id = p.id
      WHERE od.order_id = ?
    `, [orderId], (err, orderDetails) => {
      if (err) {
        console.error('خطأ في الحصول على تفاصيل الطلب:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب تفاصيل الطلب' });
      }
      
      order.details = orderDetails || [];
      
      // الحصول على الفاتورة المرتبطة بالطلب
      db.get(`
        SELECT *
        FROM invoices
        WHERE order_id = ?
      `, [orderId], (err, invoice) => {
        if (err) {
          console.error('خطأ في الحصول على الفاتورة:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء جلب الفاتورة' });
        }
        
        order.invoice = invoice || null;
        
        res.json(order);
      });
    });
  });
});

/**
 * إنشاء طلب جديد
 * POST /api/orders
 */
router.post('/', authenticate, (req, res) => {
  const { customer_id, items, discount_amount, tax_amount, notes } = req.body;
  
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: 'يرجى إدخال منتجات الطلب' });
  }
  
  // بدء المعاملة
  db.serialize(() => {
    db.run('BEGIN TRANSACTION');
    
    try {
      // إنشاء الطلب
      db.run(`
        INSERT INTO orders (
          customer_id, user_id, total_amount, discount_amount,
          tax_amount, final_amount, payment_status, order_status, notes
        ) VALUES (?, ?, 0, ?, ?, 0, 'pending', 'new', ?)
      `, [
        customer_id || null,
        req.user.id,
        discount_amount || 0,
        tax_amount || 0,
        notes || null
      ], function(err) {
        if (err) {
          console.error('خطأ في إنشاء الطلب:', err);
          db.run('ROLLBACK');
          return res.status(500).json({ message: 'حدث خطأ أثناء إنشاء الطلب' });
        }
        
        const orderId = this.lastID;
        let totalAmount = 0;
        let processedItems = 0;
        
        // إضافة تفاصيل الطلب
        items.forEach(item => {
          // التحقق من وجود المنتج وكميته
          db.get('SELECT * FROM products WHERE id = ? AND is_active = 1', [item.product_id], (err, product) => {
            if (err) {
              console.error('خطأ في الحصول على المنتج:', err);
              db.run('ROLLBACK');
              return res.status(500).json({ message: 'حدث خطأ أثناء التحقق من المنتجات' });
            }
            
            if (!product) {
              db.run('ROLLBACK');
              return res.status(400).json({ message: `المنتج رقم ${item.product_id} غير موجود أو غير نشط` });
            }
            
            if (product.quantity < item.quantity) {
              db.run('ROLLBACK');
              return res.status(400).json({ 
                message: `الكمية المطلوبة من المنتج ${product.name} غير متوفرة`,
                available: product.quantity,
                requested: item.quantity
              });
            }
            
            const unitPrice = item.unit_price || product.price;
            const discountPercent = item.discount_percent || 0;
            const totalPrice = unitPrice * item.quantity * (1 - discountPercent / 100);
            
            totalAmount += totalPrice;
            
            // إضافة تفاصيل الطلب
            db.run(`
              INSERT INTO order_details (
                order_id, product_id, quantity, unit_price,
                discount_percent, total_price
              ) VALUES (?, ?, ?, ?, ?, ?)
            `, [
              orderId,
              item.product_id,
              item.quantity,
              unitPrice,
              discountPercent,
              totalPrice
            ], function(err) {
              if (err) {
                console.error('خطأ في إضافة تفاصيل الطلب:', err);
                db.run('ROLLBACK');
                return res.status(500).json({ message: 'حدث خطأ أثناء إضافة تفاصيل الطلب' });
              }
              
              // تحديث المخزون
              db.run(`
                UPDATE products
                SET quantity = quantity - ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
              `, [item.quantity, item.product_id], function(err) {
                if (err) {
                  console.error('خطأ في تحديث المخزون:', err);
                  db.run('ROLLBACK');
                  return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المخزون' });
                }
                
                // تسجيل عملية تغيير المخزون
                db.run(`
                  INSERT INTO inventory_log (
                    product_id, user_id, quantity_change, previous_quantity, 
                    new_quantity, action_type, reference_id, reference_type, notes
                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                  item.product_id,
                  req.user.id,
                  -item.quantity,
                  product.quantity,
                  product.quantity - item.quantity,
                  'order',
                  orderId,
                  'order',
                  `خصم من المخزون للطلب رقم ${orderId}`
                ], (err) => {
                  if (err) {
                    console.error('خطأ في تسجيل المخزون:', err);
                    // لا نقوم بإلغاء المعاملة هنا لأن هذا مجرد سجل
                  }
                  
                  processedItems++;
                  
                  // إذا تمت معالجة جميع العناصر، نقوم بتحديث إجمالي الطلب
                  if (processedItems === items.length) {
                    const discountAmount = discount_amount || 0;
                    const taxAmount = tax_amount || 0;
                    const finalAmount = totalAmount - discountAmount + taxAmount;
                    
                    // تحديث إجمالي الطلب
                    db.run(`
                      UPDATE orders
                      SET total_amount = ?, final_amount = ?, updated_at = CURRENT_TIMESTAMP
                      WHERE id = ?
                    `, [totalAmount, finalAmount, orderId], function(err) {
                      if (err) {
                        console.error('خطأ في تحديث إجمالي الطلب:', err);
                        db.run('ROLLBACK');
                        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث إجمالي الطلب' });
                      }
                      
                      // إنشاء فاتورة للطلب
                      const invoiceNumber = `INV-${new Date().getFullYear()}-${orderId.toString().padStart(5, '0')}`;
                      
                      db.run(`
                        INSERT INTO invoices (
                          order_id, invoice_number, invoice_date, payment_status
                        ) VALUES (?, ?, CURRENT_TIMESTAMP, 'pending')
                      `, [orderId, invoiceNumber], function(err) {
                        if (err) {
                          console.error('خطأ في إنشاء الفاتورة:', err);
                          db.run('ROLLBACK');
                          return res.status(500).json({ message: 'حدث خطأ أثناء إنشاء الفاتورة' });
                        }
                        
                        const invoiceId = this.lastID;
                        
                        // إتمام المعاملة
                        db.run('COMMIT', (err) => {
                          if (err) {
                            console.error('خطأ في إتمام المعاملة:', err);
                            db.run('ROLLBACK');
                            return res.status(500).json({ message: 'حدث خطأ أثناء إتمام المعاملة' });
                          }
                          
                          res.status(201).json({
                            message: 'تم إنشاء الطلب والفاتورة بنجاح',
                            orderId,
                            invoiceId,
                            invoiceNumber
                          });
                        });
                      });
                    });
                  }
                });
              });
            });
          });
        });
      });
    } catch (error) {
      console.error('خطأ غير متوقع:', error);
      db.run('ROLLBACK');
      res.status(500).json({ message: 'حدث خطأ غير متوقع أثناء إنشاء الطلب' });
    }
  });
});

/**
 * تحديث حالة الطلب
 * PUT /api/orders/:id/status
 */
router.put('/:id/status', authenticate, (req, res) => {
  const orderId = req.params.id;
  const { status } = req.body;
  
  if (!status) {
    return res.status(400).json({ message: 'يرجى تحديد حالة الطلب' });
  }
  
  // التحقق من وجود الطلب
  db.get('SELECT * FROM orders WHERE id = ?', [orderId], (err, order) => {
    if (err) {
      console.error('خطأ في الحصول على الطلب:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الطلب' });
    }
    
    if (!order) {
      return res.status(404).json({ message: 'الطلب غير موجود' });
    }
    
    // تحديث حالة الطلب
    db.run(`
      UPDATE orders
      SET order_status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [status, orderId], function(err) {
      if (err) {
        console.error('خطأ في تحديث حالة الطلب:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الطلب' });
      }
      
      res.json({ message: 'تم تحديث حالة الطلب بنجاح' });
    });
  });
});

/**
 * تحديث حالة الدفع
 * PUT /api/orders/:id/payment
 */
router.put('/:id/payment', authenticate, (req, res) => {
  const orderId = req.params.id;
  const { payment_status, payment_method } = req.body;
  
  if (!payment_status) {
    return res.status(400).json({ message: 'يرجى تحديد حالة الدفع' });
  }
  
  // التحقق من وجود الطلب
  db.get('SELECT * FROM orders WHERE id = ?', [orderId], (err, order) => {
    if (err) {
      console.error('خطأ في الحصول على الطلب:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع' });
    }
    
    if (!order) {
      return res.status(404).json({ message: 'الطلب غير موجود' });
    }
    
    // تحديث حالة الدفع للطلب
    db.run(`
      UPDATE orders
      SET payment_status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [payment_status, orderId], function(err) {
      if (err) {
        console.error('خطأ في تحديث حالة الدفع للطلب:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع' });
      }
      
      // تحديث حالة الدفع للفاتورة
      db.run(`
        UPDATE invoices
        SET payment_status = ?, payment_method = ?, updated_at = CURRENT_TIMESTAMP
        WHERE order_id = ?
      `, [payment_status, payment_method || null, orderId], function(err) {
        if (err) {
          console.error('خطأ في تحديث حالة الدفع للفاتورة:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع للفاتورة' });
        }
        
        res.json({ message: 'تم تحديث حالة الدفع بنجاح' });
      });
    });
  });
});

/**
 * إلغاء طلب
 * DELETE /api/orders/:id
 */
router.delete('/:id', authenticate, authorize(['admin', 'manager']), (req, res) => {
  const orderId = req.params.id;
  
  // التحقق من وجود الطلب
  db.get('SELECT * FROM orders WHERE id = ?', [orderId], (err, order) => {
    if (err) {
      console.error('خطأ في الحصول على الطلب:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء إلغاء الطلب' });
    }
    
    if (!order) {
      return res.status(404).json({ message: 'الطلب غير موجود' });
    }
    
    // التحقق من حالة الطلب
    if (order.order_status === 'completed' || order.order_status === 'cancelled') {
      return res.status(400).json({ message: 'لا يمكن إلغاء طلب مكتمل أو ملغي بالفعل' });
    }
    
    // بدء المعاملة
    db.serialize(() => {
      db.run('BEGIN TRANSACTION');
      
      try {
        // الحصول على تفاصيل الطلب لإعادة المنتجات للمخزون
        db.all('SELECT * FROM order_details WHERE order_id = ?', [orderId], (err, orderDetails) => {
          if (err) {
            console.error('خطأ في الحصول على تفاصيل الطلب:', err);
            db.run('ROLLBACK');
            return res.status(500).json({ message: 'حدث خطأ أثناء إلغاء الطلب' });
          }
          
          let processedItems = 0;
          
          // إذا لم يكن هناك تفاصيل، نقوم بتحديث حالة الطلب فقط
          if (!orderDetails || orderDetails.length === 0) {
            updateOrderStatus();
            return;
          }
          
          // إعادة المنتجات للمخزون
          orderDetails.forEach(detail => {
            // تحديث المخزون
            db.run(`
              UPDATE products
              SET quantity = quantity + ?, updated_at = CURRENT_TIMESTAMP
              WHERE id = ?
            `, [detail.quantity, detail.product_id], function(err) {
              if (err) {
                console.error('خطأ في تحديث المخزون:', err);
                db.run('ROLLBACK');
                return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المخزون' });
              }
              
              // الحصول على الكمية الحالية للمنتج
              db.get('SELECT quantity FROM products WHERE id = ?', [detail.product_id], (err, product) => {
                if (err) {
                  console.error('خطأ في الحصول على كمية المنتج:', err);
                  db.run('ROLLBACK');
                  return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المخزون' });
                }
                
                // تسجيل عملية تغيير المخزون
                db.run(`
                  INSERT INTO inventory_log (
                    product_id, user_id, quantity_change, previous_quantity, 
                    new_quantity, action_type, reference_id, reference_type, notes
                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                  detail.product_id,
                  req.user.id,
                  detail.quantity,
                  product.quantity - detail.quantity,
                  product.quantity,
                  'order_cancel',
                  orderId,
                  'order',
                  `إعادة للمخزون بسبب إلغاء الطلب رقم ${orderId}`
                ], (err) => {
                  if (err) {
                    console.error('خطأ في تسجيل المخزون:', err);
                    // لا نقوم بإلغاء المعاملة هنا لأن هذا مجرد سجل
                  }
                  
                  processedItems++;
                  
                  // إذا تمت معالجة جميع العناصر، نقوم بتحديث حالة الطلب
                  if (processedItems === orderDetails.length) {
                    updateOrderStatus();
                  }
                });
              });
            });
          });
          
          function updateOrderStatus() {
            // تحديث حالة الطلب
            db.run(`
              UPDATE orders
              SET order_status = 'cancelled', updated_at = CURRENT_TIMESTAMP
              WHERE id = ?
            `, [orderId], function(err) {
              if (err) {
                console.error('خطأ في تحديث حالة الطلب:', err);
                db.run('ROLLBACK');
                return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الطلب' });
              }
              
              // تحديث حالة الفاتورة
              db.run(`
                UPDATE invoices
                SET payment_status = 'cancelled', updated_at = CURRENT_TIMESTAMP
                WHERE order_id = ?
              `, [orderId], function(err) {
                if (err) {
                  console.error('خطأ في تحديث حالة الفاتورة:', err);
                  db.run('ROLLBACK');
                  return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الفاتورة' });
                }
                
                // إتمام المعاملة
                db.run('COMMIT', (err) => {
                  if (err) {
                    console.error('خطأ في إتمام المعاملة:', err);
                    db.run('ROLLBACK');
                    return res.status(500).json({ message: 'حدث خطأ أثناء إتمام المعاملة' });
                  }
                  
                  res.json({ message: 'تم إلغاء الطلب بنجاح' });
                });
              });
            });
          }
        });
      } catch (error) {
        console.error('خطأ غير متوقع:', error);
        db.run('ROLLBACK');
        res.status(500).json({ message: 'حدث خطأ غير متوقع أثناء إلغاء الطلب' });
      }
    });
  });
});

module.exports = router;

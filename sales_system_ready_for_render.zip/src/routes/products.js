/**
 * مسارات المنتجات
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// إعداد تخزين الصور
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '..', 'public', 'uploads', 'products');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, 'product-' + uniqueSuffix + ext);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 ميجابايت
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('يجب أن تكون الصورة من نوع: jpeg, jpg, png, gif'));
    }
  }
});

/**
 * الحصول على جميع المنتجات
 * GET /api/products
 */
router.get('/', authenticate, (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const search = req.query.search || '';
  const category = req.query.category || '';
  
  let query = `
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1
  `;
  
  const params = [];
  
  if (search) {
    query += ` AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)`;
    const searchParam = `%${search}%`;
    params.push(searchParam, searchParam, searchParam, searchParam);
  }
  
  if (category) {
    query += ` AND p.category_id = ?`;
    params.push(category);
  }
  
  query += ` ORDER BY p.name ASC LIMIT ? OFFSET ?`;
  params.push(limit, offset);
  
  // الحصول على إجمالي عدد المنتجات للترقيم
  let countQuery = `
    SELECT COUNT(*) as total
    FROM products p
    WHERE p.is_active = 1
  `;
  
  const countParams = [];
  
  if (search) {
    countQuery += ` AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)`;
    const searchParam = `%${search}%`;
    countParams.push(searchParam, searchParam, searchParam, searchParam);
  }
  
  if (category) {
    countQuery += ` AND p.category_id = ?`;
    countParams.push(category);
  }
  
  db.get(countQuery, countParams, (err, countResult) => {
    if (err) {
      console.error('خطأ في الحصول على عدد المنتجات:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب المنتجات' });
    }
    
    const total = countResult.total;
    const totalPages = Math.ceil(total / limit);
    
    db.all(query, params, (err, products) => {
      if (err) {
        console.error('خطأ في الحصول على المنتجات:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب المنتجات' });
      }
      
      // تحويل مسارات الصور إلى روابط كاملة
      products.forEach(product => {
        if (product.image_path) {
          product.image_url = `/uploads/products/${path.basename(product.image_path)}`;
        } else {
          product.image_url = '/images/default-product.png';
        }
      });
      
      res.json({
        products,
        pagination: {
          total,
          totalPages,
          currentPage: page,
          limit
        }
      });
    });
  });
});

/**
 * الحصول على منتج محدد
 * GET /api/products/:id
 */
router.get('/:id', authenticate, (req, res) => {
  const productId = req.params.id;
  
  db.get(`
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = ? AND p.is_active = 1
  `, [productId], (err, product) => {
    if (err) {
      console.error('خطأ في الحصول على المنتج:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب المنتج' });
    }
    
    if (!product) {
      return res.status(404).json({ message: 'المنتج غير موجود' });
    }
    
    // تحويل مسار الصورة إلى رابط كامل
    if (product.image_path) {
      product.image_url = `/uploads/products/${path.basename(product.image_path)}`;
    } else {
      product.image_url = '/images/default-product.png';
    }
    
    res.json(product);
  });
});

/**
 * إضافة منتج جديد
 * POST /api/products
 */
router.post('/', authenticate, authorize(['admin', 'manager']), upload.single('image'), (req, res) => {
  const { name, description, sku, barcode, price, cost_price, quantity, min_quantity, category_id } = req.body;
  
  if (!name || !price) {
    return res.status(400).json({ message: 'يرجى إدخال اسم المنتج والسعر' });
  }
  
  // التحقق من عدم تكرار SKU أو الباركود
  if (sku) {
    db.get('SELECT id FROM products WHERE sku = ?', [sku], (err, existingProduct) => {
      if (err) {
        console.error('خطأ في التحقق من SKU:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء إضافة المنتج' });
      }
      
      if (existingProduct) {
        return res.status(400).json({ message: 'رمز SKU مستخدم بالفعل' });
      }
      
      continueAddingProduct();
    });
  } else {
    continueAddingProduct();
  }
  
  function continueAddingProduct() {
    // التحقق من عدم تكرار الباركود
    if (barcode) {
      db.get('SELECT id FROM products WHERE barcode = ?', [barcode], (err, existingProduct) => {
        if (err) {
          console.error('خطأ في التحقق من الباركود:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء إضافة المنتج' });
        }
        
        if (existingProduct) {
          return res.status(400).json({ message: 'الباركود مستخدم بالفعل' });
        }
        
        insertProduct();
      });
    } else {
      insertProduct();
    }
  }
  
  function insertProduct() {
    const imagePath = req.file ? req.file.filename : null;
    
    db.run(`
      INSERT INTO products (
        name, description, sku, barcode, price, cost_price, 
        quantity, min_quantity, category_id, image_path
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      name, 
      description || null, 
      sku || null, 
      barcode || null, 
      price, 
      cost_price || 0, 
      quantity || 0, 
      min_quantity || 5, 
      category_id || null, 
      imagePath
    ], function(err) {
      if (err) {
        console.error('خطأ في إضافة المنتج:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء إضافة المنتج' });
      }
      
      const productId = this.lastID;
      
      // تسجيل عملية إضافة المخزون
      if (quantity && quantity > 0) {
        db.run(`
          INSERT INTO inventory_log (
            product_id, user_id, quantity_change, previous_quantity, 
            new_quantity, action_type, notes
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          productId,
          req.user.id,
          quantity,
          0,
          quantity,
          'initial_stock',
          'إضافة مخزون أولي عند إنشاء المنتج'
        ], (err) => {
          if (err) {
            console.error('خطأ في تسجيل المخزون:', err);
          }
        });
      }
      
      res.status(201).json({ 
        message: 'تم إضافة المنتج بنجاح',
        productId
      });
    });
  }
});

/**
 * تحديث منتج
 * PUT /api/products/:id
 */
router.put('/:id', authenticate, authorize(['admin', 'manager']), upload.single('image'), (req, res) => {
  const productId = req.params.id;
  const { name, description, sku, barcode, price, cost_price, quantity, min_quantity, category_id } = req.body;
  
  if (!name || !price) {
    return res.status(400).json({ message: 'يرجى إدخال اسم المنتج والسعر' });
  }
  
  // التحقق من وجود المنتج
  db.get('SELECT * FROM products WHERE id = ?', [productId], (err, product) => {
    if (err) {
      console.error('خطأ في الحصول على المنتج:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المنتج' });
    }
    
    if (!product) {
      return res.status(404).json({ message: 'المنتج غير موجود' });
    }
    
    // التحقق من عدم تكرار SKU
    if (sku && sku !== product.sku) {
      db.get('SELECT id FROM products WHERE sku = ? AND id != ?', [sku, productId], (err, existingProduct) => {
        if (err) {
          console.error('خطأ في التحقق من SKU:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المنتج' });
        }
        
        if (existingProduct) {
          return res.status(400).json({ message: 'رمز SKU مستخدم بالفعل' });
        }
        
        checkBarcode();
      });
    } else {
      checkBarcode();
    }
    
    function checkBarcode() {
      // التحقق من عدم تكرار الباركود
      if (barcode && barcode !== product.barcode) {
        db.get('SELECT id FROM products WHERE barcode = ? AND id != ?', [barcode, productId], (err, existingProduct) => {
          if (err) {
            console.error('خطأ في التحقق من الباركود:', err);
            return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المنتج' });
          }
          
          if (existingProduct) {
            return res.status(400).json({ message: 'الباركود مستخدم بالفعل' });
          }
          
          updateProduct();
        });
      } else {
        updateProduct();
      }
    }
    
    function updateProduct() {
      let imagePath = product.image_path;
      
      // إذا تم تحميل صورة جديدة
      if (req.file) {
        imagePath = req.file.filename;
        
        // حذف الصورة القديمة إذا كانت موجودة
        if (product.image_path) {
          const oldImagePath = path.join(__dirname, '..', 'public', 'uploads', 'products', product.image_path);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
      }
      
      // تحديث المنتج
      db.run(`
        UPDATE products SET
          name = ?,
          description = ?,
          sku = ?,
          barcode = ?,
          price = ?,
          cost_price = ?,
          min_quantity = ?,
          category_id = ?,
          image_path = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [
        name,
        description || null,
        sku || null,
        barcode || null,
        price,
        cost_price || 0,
        min_quantity || 5,
        category_id || null,
        imagePath,
        productId
      ], function(err) {
        if (err) {
          console.error('خطأ في تحديث المنتج:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء تحديث المنتج' });
        }
        
        // تحديث الكمية إذا تم تغييرها
        if (quantity !== undefined && quantity !== null && quantity !== product.quantity) {
          const quantityChange = quantity - product.quantity;
          
          db.run(`
            UPDATE products SET
              quantity = ?,
              updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `, [quantity, productId], function(err) {
            if (err) {
              console.error('خطأ في تحديث كمية المنتج:', err);
              return res.status(500).json({ message: 'حدث خطأ أثناء تحديث كمية المنتج' });
            }
            
            // تسجيل عملية تغيير المخزون
            db.run(`
              INSERT INTO inventory_log (
                product_id, user_id, quantity_change, previous_quantity, 
                new_quantity, action_type, notes
              ) VALUES (?, ?, ?, ?, ?, ?, ?)
            `, [
              productId,
              req.user.id,
              quantityChange,
              product.quantity,
              quantity,
              'manual_update',
              'تعديل يدوي للمخزون'
            ], (err) => {
              if (err) {
                console.error('خطأ في تسجيل المخزون:', err);
              }
            });
            
            res.json({ message: 'تم تحديث المنتج بنجاح' });
          });
        } else {
          res.json({ message: 'تم تحديث المنتج بنجاح' });
        }
      });
    }
  });
});

/**
 * حذف منتج
 * DELETE /api/products/:id
 */
router.delete('/:id', authenticate, authorize(['admin']), (req, res) => {
  const productId = req.params.id;
  
  // التحقق من وجود المنتج
  db.get('SELECT * FROM products WHERE id = ?', [productId], (err, product) => {
    if (err) {
      console.error('خطأ في الحصول على المنتج:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء حذف المنتج' });
    }
    
    if (!product) {
      return res.status(404).json({ message: 'المنتج غير موجود' });
    }
    
    // التحقق من عدم وجود طلبات مرتبطة بالمنتج
    db.get('SELECT COUNT(*) as count FROM order_details WHERE product_id = ?', [productId], (err, result) => {
      if (err) {
        console.error('خطأ في التحقق من الطلبات:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء حذف المنتج' });
      }
      
      if (result.count > 0) {
        // تعطيل المنتج بدلاً من حذفه
        db.run('UPDATE products SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [productId], function(err) {
          if (err) {
            console.error('خطأ في تعطيل المنتج:', err);
            return res.status(500).json({ message: 'حدث خطأ أثناء تعطيل المنتج' });
          }
          
          res.json({ message: 'تم تعطيل المنتج بنجاح' });
        });
      } else {
        // حذف المنتج
        db.run('DELETE FROM products WHERE id = ?', [productId], function(err) {
          if (err) {
            console.error('خطأ في حذف المنتج:', err);
            return res.status(500).json({ message: 'حدث خطأ أثناء حذف المنتج' });
          }
          
          // حذف الصورة إذا كانت موجودة
          if (product.image_path) {
            const imagePath = path.join(__dirname, '..', 'public', 'uploads', 'products', product.image_path);
            if (fs.existsSync(imagePath)) {
              fs.unlinkSync(imagePath);
            }
          }
          
          res.json({ message: 'تم حذف المنتج بنجاح' });
        });
      }
    });
  });
});

/**
 * الحصول على فئات المنتجات
 * GET /api/products/categories
 */
router.get('/categories/all', authenticate, (req, res) => {
  db.all('SELECT * FROM categories ORDER BY name ASC', (err, categories) => {
    if (err) {
      console.error('خطأ في الحصول على الفئات:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب الفئات' });
    }
    
    res.json(categories);
  });
});

module.exports = router;

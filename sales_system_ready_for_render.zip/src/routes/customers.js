/**
 * مسارات العملاء
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * الحصول على جميع العملاء
 * GET /api/customers
 */
router.get('/', authenticate, (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const search = req.query.search || '';
  
  let query = `
    SELECT * FROM customers
    WHERE 1=1
  `;
  
  const params = [];
  
  if (search) {
    query += ` AND (name LIKE ? OR phone LIKE ? OR email LIKE ? OR address LIKE ?)`;
    const searchParam = `%${search}%`;
    params.push(searchParam, searchParam, searchParam, searchParam);
  }
  
  query += ` ORDER BY name ASC LIMIT ? OFFSET ?`;
  params.push(limit, offset);
  
  // الحصول على إجمالي عدد العملاء للترقيم
  let countQuery = `
    SELECT COUNT(*) as total
    FROM customers
    WHERE 1=1
  `;
  
  const countParams = [];
  
  if (search) {
    countQuery += ` AND (name LIKE ? OR phone LIKE ? OR email LIKE ? OR address LIKE ?)`;
    const searchParam = `%${search}%`;
    countParams.push(searchParam, searchParam, searchParam, searchParam);
  }
  
  db.get(countQuery, countParams, (err, countResult) => {
    if (err) {
      console.error('خطأ في الحصول على عدد العملاء:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب العملاء' });
    }
    
    const total = countResult.total;
    const totalPages = Math.ceil(total / limit);
    
    db.all(query, params, (err, customers) => {
      if (err) {
        console.error('خطأ في الحصول على العملاء:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب العملاء' });
      }
      
      res.json({
        customers,
        pagination: {
          total,
          totalPages,
          currentPage: page,
          limit
        }
      });
    });
  });
});

/**
 * الحصول على عميل محدد
 * GET /api/customers/:id
 */
router.get('/:id', authenticate, (req, res) => {
  const customerId = req.params.id;
  
  db.get('SELECT * FROM customers WHERE id = ?', [customerId], (err, customer) => {
    if (err) {
      console.error('خطأ في الحصول على العميل:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب العميل' });
    }
    
    if (!customer) {
      return res.status(404).json({ message: 'العميل غير موجود' });
    }
    
    // الحصول على طلبات العميل
    db.all(`
      SELECT o.*, 
        (SELECT COUNT(*) FROM order_details WHERE order_id = o.id) as items_count
      FROM orders o
      WHERE o.customer_id = ?
      ORDER BY o.order_date DESC
      LIMIT 10
    `, [customerId], (err, orders) => {
      if (err) {
        console.error('خطأ في الحصول على طلبات العميل:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب طلبات العميل' });
      }
      
      customer.recent_orders = orders || [];
      
      // حساب إجمالي مشتريات العميل
      db.get(`
        SELECT SUM(final_amount) as total_purchases
        FROM orders
        WHERE customer_id = ?
      `, [customerId], (err, result) => {
        if (err) {
          console.error('خطأ في حساب إجمالي مشتريات العميل:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء حساب إجمالي مشتريات العميل' });
        }
        
        customer.total_purchases = result ? result.total_purchases || 0 : 0;
        
        res.json(customer);
      });
    });
  });
});

/**
 * إضافة عميل جديد
 * POST /api/customers
 */
router.post('/', authenticate, (req, res) => {
  const { name, phone, email, address, notes } = req.body;
  
  if (!name) {
    return res.status(400).json({ message: 'يرجى إدخال اسم العميل' });
  }
  
  // التحقق من عدم تكرار رقم الهاتف أو البريد الإلكتروني
  let checkQuery = 'SELECT id FROM customers WHERE ';
  const checkParams = [];
  
  if (phone) {
    checkQuery += 'phone = ?';
    checkParams.push(phone);
  }
  
  if (email) {
    if (checkParams.length > 0) {
      checkQuery += ' OR email = ?';
    } else {
      checkQuery += 'email = ?';
    }
    checkParams.push(email);
  }
  
  // إذا لم يتم تحديد هاتف أو بريد إلكتروني، نتخطى التحقق
  if (checkParams.length === 0) {
    insertCustomer();
    return;
  }
  
  db.get(checkQuery, checkParams, (err, existingCustomer) => {
    if (err) {
      console.error('خطأ في التحقق من بيانات العميل:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء إضافة العميل' });
    }
    
    if (existingCustomer) {
      return res.status(400).json({ message: 'رقم الهاتف أو البريد الإلكتروني مستخدم بالفعل' });
    }
    
    insertCustomer();
  });
  
  function insertCustomer() {
    db.run(`
      INSERT INTO customers (name, phone, email, address, notes)
      VALUES (?, ?, ?, ?, ?)
    `, [name, phone || null, email || null, address || null, notes || null], function(err) {
      if (err) {
        console.error('خطأ في إضافة العميل:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء إضافة العميل' });
      }
      
      const customerId = this.lastID;
      
      res.status(201).json({ 
        message: 'تم إضافة العميل بنجاح',
        customerId
      });
    });
  }
});

/**
 * تحديث عميل
 * PUT /api/customers/:id
 */
router.put('/:id', authenticate, (req, res) => {
  const customerId = req.params.id;
  const { name, phone, email, address, notes } = req.body;
  
  if (!name) {
    return res.status(400).json({ message: 'يرجى إدخال اسم العميل' });
  }
  
  // التحقق من وجود العميل
  db.get('SELECT * FROM customers WHERE id = ?', [customerId], (err, customer) => {
    if (err) {
      console.error('خطأ في الحصول على العميل:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تحديث العميل' });
    }
    
    if (!customer) {
      return res.status(404).json({ message: 'العميل غير موجود' });
    }
    
    // التحقق من عدم تكرار رقم الهاتف أو البريد الإلكتروني
    let checkQuery = 'SELECT id FROM customers WHERE id != ? AND (';
    const checkParams = [customerId];
    
    if (phone && phone !== customer.phone) {
      checkQuery += 'phone = ?';
      checkParams.push(phone);
    }
    
    if (email && email !== customer.email) {
      if (checkParams.length > 1) {
        checkQuery += ' OR email = ?';
      } else {
        checkQuery += 'email = ?';
      }
      checkParams.push(email);
    }
    
    checkQuery += ')';
    
    // إذا لم يتم تغيير الهاتف أو البريد الإلكتروني، نتخطى التحقق
    if (checkParams.length === 1 || 
        (phone === customer.phone && email === customer.email)) {
      updateCustomer();
      return;
    }
    
    db.get(checkQuery, checkParams, (err, existingCustomer) => {
      if (err) {
        console.error('خطأ في التحقق من بيانات العميل:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث العميل' });
      }
      
      if (existingCustomer) {
        return res.status(400).json({ message: 'رقم الهاتف أو البريد الإلكتروني مستخدم بالفعل' });
      }
      
      updateCustomer();
    });
  });
  
  function updateCustomer() {
    db.run(`
      UPDATE customers SET
        name = ?,
        phone = ?,
        email = ?,
        address = ?,
        notes = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [name, phone || null, email || null, address || null, notes || null, customerId], function(err) {
      if (err) {
        console.error('خطأ في تحديث العميل:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث العميل' });
      }
      
      res.json({ message: 'تم تحديث العميل بنجاح' });
    });
  }
});

/**
 * حذف عميل
 * DELETE /api/customers/:id
 */
router.delete('/:id', authenticate, authorize(['admin']), (req, res) => {
  const customerId = req.params.id;
  
  // التحقق من وجود العميل
  db.get('SELECT * FROM customers WHERE id = ?', [customerId], (err, customer) => {
    if (err) {
      console.error('خطأ في الحصول على العميل:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء حذف العميل' });
    }
    
    if (!customer) {
      return res.status(404).json({ message: 'العميل غير موجود' });
    }
    
    // التحقق من عدم وجود طلبات مرتبطة بالعميل
    db.get('SELECT COUNT(*) as count FROM orders WHERE customer_id = ?', [customerId], (err, result) => {
      if (err) {
        console.error('خطأ في التحقق من الطلبات:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء حذف العميل' });
      }
      
      if (result.count > 0) {
        return res.status(400).json({ 
          message: 'لا يمكن حذف العميل لوجود طلبات مرتبطة به',
          ordersCount: result.count
        });
      }
      
      // حذف العميل
      db.run('DELETE FROM customers WHERE id = ?', [customerId], function(err) {
        if (err) {
          console.error('خطأ في حذف العميل:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء حذف العميل' });
        }
        
        res.json({ message: 'تم حذف العميل بنجاح' });
      });
    });
  });
});

/**
 * البحث عن العملاء
 * GET /api/customers/search
 */
router.get('/search/query', authenticate, (req, res) => {
  const query = req.query.q || '';
  const limit = parseInt(req.query.limit) || 10;
  
  if (!query || query.length < 2) {
    return res.json({ customers: [] });
  }
  
  const searchQuery = `
    SELECT id, name, phone, email
    FROM customers
    WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
    ORDER BY name ASC
    LIMIT ?
  `;
  
  const searchParam = `%${query}%`;
  
  db.all(searchQuery, [searchParam, searchParam, searchParam, limit], (err, customers) => {
    if (err) {
      console.error('خطأ في البحث عن العملاء:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء البحث عن العملاء' });
    }
    
    res.json({ customers });
  });
});

module.exports = router;

/**
 * مسارات المصادقة
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require('../config/database');
const { generateToken } = require('../middleware/auth');

/**
 * تسجيل الدخول
 * POST /api/auth/login
 */
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ message: 'يرجى إدخال اسم المستخدم وكلمة المرور' });
  }
  
  db.get('SELECT * FROM users WHERE username = ? AND is_active = 1', [username], (err, user) => {
    if (err) {
      console.error('خطأ في قاعدة البيانات:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تسجيل الدخول' });
    }
    
    if (!user) {
      return res.status(401).json({ message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }
    
    // التحقق من كلمة المرور
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) {
        console.error('خطأ في التحقق من كلمة المرور:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تسجيل الدخول' });
      }
      
      if (!isMatch) {
        return res.status(401).json({ message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
      }
      
      // إنشاء توكن JWT
      const token = generateToken(user);
      
      // إرسال التوكن في الكوكيز
      res.cookie('token', token, {
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 ساعة
        sameSite: 'strict'
      });
      
      // إرسال بيانات المستخدم والتوكن
      res.json({
        message: 'تم تسجيل الدخول بنجاح',
        user: {
          id: user.id,
          username: user.username,
          fullName: user.full_name,
          role: user.role
        },
        token
      });
    });
  });
});

/**
 * تسجيل الخروج
 * POST /api/auth/logout
 */
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'تم تسجيل الخروج بنجاح' });
});

/**
 * التحقق من حالة المصادقة
 * GET /api/auth/check
 */
router.get('/check', (req, res) => {
  const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ authenticated: false });
  }
  
  try {
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, 'sales_system_secret_key_2025');
    
    db.get('SELECT * FROM users WHERE id = ? AND is_active = 1', [decoded.userId], (err, user) => {
      if (err || !user) {
        return res.status(401).json({ authenticated: false });
      }
      
      res.json({
        authenticated: true,
        user: {
          id: user.id,
          username: user.username,
          fullName: user.full_name,
          role: user.role
        }
      });
    });
  } catch (error) {
    res.status(401).json({ authenticated: false });
  }
});

/**
 * تغيير كلمة المرور
 * PUT /api/auth/change-password
 */
router.put('/change-password', (req, res) => {
  const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'غير مصرح بالوصول، يرجى تسجيل الدخول' });
  }
  
  try {
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, 'sales_system_secret_key_2025');
    
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'يرجى إدخال كلمة المرور الحالية والجديدة' });
    }
    
    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'يجب أن تكون كلمة المرور الجديدة 6 أحرف على الأقل' });
    }
    
    db.get('SELECT * FROM users WHERE id = ? AND is_active = 1', [decoded.userId], (err, user) => {
      if (err || !user) {
        return res.status(401).json({ message: 'المستخدم غير موجود أو غير نشط' });
      }
      
      // التحقق من كلمة المرور الحالية
      bcrypt.compare(currentPassword, user.password, (err, isMatch) => {
        if (err) {
          console.error('خطأ في التحقق من كلمة المرور:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء تغيير كلمة المرور' });
        }
        
        if (!isMatch) {
          return res.status(401).json({ message: 'كلمة المرور الحالية غير صحيحة' });
        }
        
        // تشفير كلمة المرور الجديدة
        bcrypt.hash(newPassword, 10, (err, hash) => {
          if (err) {
            console.error('خطأ في تشفير كلمة المرور:', err);
            return res.status(500).json({ message: 'حدث خطأ أثناء تغيير كلمة المرور' });
          }
          
          // تحديث كلمة المرور في قاعدة البيانات
          db.run('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [hash, user.id], function(err) {
            if (err) {
              console.error('خطأ في تحديث كلمة المرور:', err);
              return res.status(500).json({ message: 'حدث خطأ أثناء تغيير كلمة المرور' });
            }
            
            res.json({ message: 'تم تغيير كلمة المرور بنجاح' });
          });
        });
      });
    });
  } catch (error) {
    console.error('خطأ في المصادقة:', error);
    res.status(401).json({ message: 'غير مصرح بالوصول، يرجى تسجيل الدخول' });
  }
});

module.exports = router;

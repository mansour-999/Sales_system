/**
 * مسارات الفواتير
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const path = require('path');
const fs = require('fs');

/**
 * الحصول على جميع الفواتير
 * GET /api/invoices
 */
router.get('/', authenticate, (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const offset = (page - 1) * limit;
  const status = req.query.status || '';
  const dateFrom = req.query.dateFrom || '';
  const dateTo = req.query.dateTo || '';
  
  let query = `
    SELECT i.*, o.final_amount, c.name as customer_name
    FROM invoices i
    LEFT JOIN orders o ON i.order_id = o.id
    LEFT JOIN customers c ON o.customer_id = c.id
    WHERE 1=1
  `;
  
  const params = [];
  
  if (status) {
    query += ` AND i.payment_status = ?`;
    params.push(status);
  }
  
  if (dateFrom) {
    query += ` AND i.invoice_date >= ?`;
    params.push(dateFrom);
  }
  
  if (dateTo) {
    query += ` AND i.invoice_date <= ?`;
    params.push(dateTo);
  }
  
  query += ` ORDER BY i.invoice_date DESC LIMIT ? OFFSET ?`;
  params.push(limit, offset);
  
  // الحصول على إجمالي عدد الفواتير للترقيم
  let countQuery = `
    SELECT COUNT(*) as total
    FROM invoices i
    WHERE 1=1
  `;
  
  const countParams = [];
  
  if (status) {
    countQuery += ` AND i.payment_status = ?`;
    countParams.push(status);
  }
  
  if (dateFrom) {
    countQuery += ` AND i.invoice_date >= ?`;
    countParams.push(dateFrom);
  }
  
  if (dateTo) {
    countQuery += ` AND i.invoice_date <= ?`;
    countParams.push(dateTo);
  }
  
  db.get(countQuery, countParams, (err, countResult) => {
    if (err) {
      console.error('خطأ في الحصول على عدد الفواتير:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب الفواتير' });
    }
    
    const total = countResult.total;
    const totalPages = Math.ceil(total / limit);
    
    db.all(query, params, (err, invoices) => {
      if (err) {
        console.error('خطأ في الحصول على الفواتير:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب الفواتير' });
      }
      
      res.json({
        invoices,
        pagination: {
          total,
          totalPages,
          currentPage: page,
          limit
        }
      });
    });
  });
});

/**
 * الحصول على فاتورة محددة
 * GET /api/invoices/:id
 */
router.get('/:id', authenticate, (req, res) => {
  const invoiceId = req.params.id;
  
  db.get(`
    SELECT i.*, o.final_amount, o.total_amount, o.discount_amount, o.tax_amount,
           o.order_date, o.order_status, o.notes as order_notes,
           c.name as customer_name, c.phone as customer_phone, c.email as customer_email,
           c.address as customer_address
    FROM invoices i
    LEFT JOIN orders o ON i.order_id = o.id
    LEFT JOIN customers c ON o.customer_id = c.id
    WHERE i.id = ?
  `, [invoiceId], (err, invoice) => {
    if (err) {
      console.error('خطأ في الحصول على الفاتورة:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب الفاتورة' });
    }
    
    if (!invoice) {
      return res.status(404).json({ message: 'الفاتورة غير موجودة' });
    }
    
    // الحصول على تفاصيل الطلب
    db.all(`
      SELECT od.*, p.name as product_name, p.sku as product_sku
      FROM order_details od
      LEFT JOIN products p ON od.product_id = p.id
      WHERE od.order_id = ?
    `, [invoice.order_id], (err, orderDetails) => {
      if (err) {
        console.error('خطأ في الحصول على تفاصيل الطلب:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب تفاصيل الطلب' });
      }
      
      invoice.details = orderDetails || [];
      
      res.json(invoice);
    });
  });
});

/**
 * تحديث حالة الدفع للفاتورة
 * PUT /api/invoices/:id/payment
 */
router.put('/:id/payment', authenticate, (req, res) => {
  const invoiceId = req.params.id;
  const { payment_status, payment_method } = req.body;
  
  if (!payment_status) {
    return res.status(400).json({ message: 'يرجى تحديد حالة الدفع' });
  }
  
  // التحقق من وجود الفاتورة
  db.get('SELECT * FROM invoices WHERE id = ?', [invoiceId], (err, invoice) => {
    if (err) {
      console.error('خطأ في الحصول على الفاتورة:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع' });
    }
    
    if (!invoice) {
      return res.status(404).json({ message: 'الفاتورة غير موجودة' });
    }
    
    // تحديث حالة الدفع للفاتورة
    db.run(`
      UPDATE invoices
      SET payment_status = ?, payment_method = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [payment_status, payment_method || null, invoiceId], function(err) {
      if (err) {
        console.error('خطأ في تحديث حالة الدفع للفاتورة:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع للفاتورة' });
      }
      
      // تحديث حالة الدفع للطلب
      db.run(`
        UPDATE orders
        SET payment_status = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [payment_status, invoice.order_id], function(err) {
        if (err) {
          console.error('خطأ في تحديث حالة الدفع للطلب:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء تحديث حالة الدفع للطلب' });
        }
        
        res.json({ message: 'تم تحديث حالة الدفع بنجاح' });
      });
    });
  });
});

/**
 * إنشاء PDF للفاتورة
 * GET /api/invoices/:id/pdf
 */
router.get('/:id/pdf', authenticate, (req, res) => {
  const invoiceId = req.params.id;
  
  // هنا يمكن إضافة كود لإنشاء ملف PDF للفاتورة
  // يمكن استخدام مكتبات مثل PDFKit أو html-pdf
  
  res.json({
    message: 'سيتم تنفيذ هذه الميزة في الإصدار القادم',
    invoiceId
  });
});

/**
 * إرسال الفاتورة بالبريد الإلكتروني
 * POST /api/invoices/:id/email
 */
router.post('/:id/email', authenticate, (req, res) => {
  const invoiceId = req.params.id;
  const { email } = req.body;
  
  if (!email) {
    return res.status(400).json({ message: 'يرجى تحديد البريد الإلكتروني' });
  }
  
  // هنا يمكن إضافة كود لإرسال الفاتورة بالبريد الإلكتروني
  // يمكن استخدام مكتبات مثل Nodemailer
  
  res.json({
    message: 'سيتم تنفيذ هذه الميزة في الإصدار القادم',
    invoiceId,
    email
  });
});

module.exports = router;

/**
 * مسارات التقارير
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * تقرير المبيعات
 * GET /api/reports/sales
 */
router.get('/sales', authenticate, (req, res) => {
  const period = req.query.period || 'daily'; // daily, weekly, monthly, yearly
  const dateFrom = req.query.dateFrom || '';
  const dateTo = req.query.dateTo || '';
  
  let groupBy, dateFormat;
  
  switch (period) {
    case 'daily':
      groupBy = "strftime('%Y-%m-%d', order_date)";
      dateFormat = '%Y-%m-%d';
      break;
    case 'weekly':
      groupBy = "strftime('%Y-%W', order_date)";
      dateFormat = '%Y-%W';
      break;
    case 'monthly':
      groupBy = "strftime('%Y-%m', order_date)";
      dateFormat = '%Y-%m';
      break;
    case 'yearly':
      groupBy = "strftime('%Y', order_date)";
      dateFormat = '%Y';
      break;
    default:
      groupBy = "strftime('%Y-%m-%d', order_date)";
      dateFormat = '%Y-%m-%d';
  }
  
  let query = `
    SELECT 
      ${groupBy} as date_group,
      COUNT(*) as orders_count,
      SUM(total_amount) as total_sales,
      SUM(discount_amount) as total_discounts,
      SUM(tax_amount) as total_taxes,
      SUM(final_amount) as final_sales
    FROM orders
    WHERE order_status != 'cancelled'
  `;
  
  const params = [];
  
  if (dateFrom) {
    query += ` AND order_date >= ?`;
    params.push(dateFrom);
  }
  
  if (dateTo) {
    query += ` AND order_date <= ?`;
    params.push(dateTo);
  }
  
  query += ` GROUP BY date_group ORDER BY date_group`;
  
  db.all(query, params, (err, salesData) => {
    if (err) {
      console.error('خطأ في الحصول على تقرير المبيعات:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب تقرير المبيعات' });
    }
    
    // حساب الإجماليات
    let totalOrders = 0;
    let totalSales = 0;
    let totalDiscounts = 0;
    let totalTaxes = 0;
    let totalFinalSales = 0;
    
    salesData.forEach(item => {
      totalOrders += item.orders_count;
      totalSales += item.total_sales;
      totalDiscounts += item.total_discounts;
      totalTaxes += item.total_taxes;
      totalFinalSales += item.final_sales;
    });
    
    res.json({
      period,
      salesData,
      summary: {
        totalOrders,
        totalSales,
        totalDiscounts,
        totalTaxes,
        totalFinalSales
      }
    });
  });
});

/**
 * تقرير المنتجات الأكثر مبيعاً
 * GET /api/reports/top-products
 */
router.get('/top-products', authenticate, (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  const dateFrom = req.query.dateFrom || '';
  const dateTo = req.query.dateTo || '';
  
  let query = `
    SELECT 
      p.id, p.name, p.sku, p.price,
      SUM(od.quantity) as total_quantity,
      SUM(od.total_price) as total_sales
    FROM order_details od
    JOIN products p ON od.product_id = p.id
    JOIN orders o ON od.order_id = o.id
    WHERE o.order_status != 'cancelled'
  `;
  
  const params = [];
  
  if (dateFrom) {
    query += ` AND o.order_date >= ?`;
    params.push(dateFrom);
  }
  
  if (dateTo) {
    query += ` AND o.order_date <= ?`;
    params.push(dateTo);
  }
  
  query += ` GROUP BY p.id ORDER BY total_quantity DESC LIMIT ?`;
  params.push(limit);
  
  db.all(query, params, (err, products) => {
    if (err) {
      console.error('خطأ في الحصول على تقرير المنتجات الأكثر مبيعاً:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب تقرير المنتجات الأكثر مبيعاً' });
    }
    
    res.json({
      products
    });
  });
});

/**
 * تقرير العملاء الأكثر شراءً
 * GET /api/reports/top-customers
 */
router.get('/top-customers', authenticate, (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  const dateFrom = req.query.dateFrom || '';
  const dateTo = req.query.dateTo || '';
  
  let query = `
    SELECT 
      c.id, c.name, c.phone, c.email,
      COUNT(o.id) as orders_count,
      SUM(o.final_amount) as total_spent
    FROM orders o
    JOIN customers c ON o.customer_id = c.id
    WHERE o.order_status != 'cancelled'
  `;
  
  const params = [];
  
  if (dateFrom) {
    query += ` AND o.order_date >= ?`;
    params.push(dateFrom);
  }
  
  if (dateTo) {
    query += ` AND o.order_date <= ?`;
    params.push(dateTo);
  }
  
  query += ` GROUP BY c.id ORDER BY total_spent DESC LIMIT ?`;
  params.push(limit);
  
  db.all(query, params, (err, customers) => {
    if (err) {
      console.error('خطأ في الحصول على تقرير العملاء الأكثر شراءً:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب تقرير العملاء الأكثر شراءً' });
    }
    
    res.json({
      customers
    });
  });
});

/**
 * تقرير المخزون
 * GET /api/reports/inventory
 */
router.get('/inventory', authenticate, (req, res) => {
  const lowStock = req.query.lowStock === 'true';
  
  let query = `
    SELECT 
      p.id, p.name, p.sku, p.price, p.quantity, p.min_quantity,
      c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1
  `;
  
  if (lowStock) {
    query += ` AND p.quantity <= p.min_quantity`;
  }
  
  query += ` ORDER BY p.quantity ASC`;
  
  db.all(query, [], (err, products) => {
    if (err) {
      console.error('خطأ في الحصول على تقرير المخزون:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب تقرير المخزون' });
    }
    
    // حساب إحصائيات المخزون
    let totalProducts = products.length;
    let totalItems = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;
    
    products.forEach(product => {
      totalItems += product.quantity;
      
      if (product.quantity <= product.min_quantity) {
        lowStockCount++;
      }
      
      if (product.quantity === 0) {
        outOfStockCount++;
      }
    });
    
    res.json({
      products,
      summary: {
        totalProducts,
        totalItems,
        lowStockCount,
        outOfStockCount
      }
    });
  });
});

/**
 * تقرير الإحصائيات العامة
 * GET /api/reports/dashboard
 */
router.get('/dashboard', authenticate, (req, res) => {
  // الحصول على إحصائيات اليوم
  const today = new Date().toISOString().split('T')[0];
  
  // إحصائيات المبيعات اليومية
  db.get(`
    SELECT 
      COUNT(*) as orders_count,
      SUM(final_amount) as total_sales
    FROM orders
    WHERE order_status != 'cancelled'
    AND date(order_date) = date('now')
  `, [], (err, todaySales) => {
    if (err) {
      console.error('خطأ في الحصول على إحصائيات المبيعات اليومية:', err);
      return res.status(500).json({ message: 'حدث خطأ أثناء جلب إحصائيات المبيعات اليومية' });
    }
    
    // إحصائيات المبيعات الشهرية
    db.get(`
      SELECT 
        COUNT(*) as orders_count,
        SUM(final_amount) as total_sales
      FROM orders
      WHERE order_status != 'cancelled'
      AND strftime('%Y-%m', order_date) = strftime('%Y-%m', 'now')
    `, [], (err, monthlySales) => {
      if (err) {
        console.error('خطأ في الحصول على إحصائيات المبيعات الشهرية:', err);
        return res.status(500).json({ message: 'حدث خطأ أثناء جلب إحصائيات المبيعات الشهرية' });
      }
      
      // عدد العملاء
      db.get(`SELECT COUNT(*) as count FROM customers`, [], (err, customersCount) => {
        if (err) {
          console.error('خطأ في الحصول على عدد العملاء:', err);
          return res.status(500).json({ message: 'حدث خطأ أثناء جلب عدد العملاء' });
        }
        
        // عدد المنتجات
        db.get(`SELECT COUNT(*) as count FROM products WHERE is_active = 1`, [], (err, productsCount) => {
          if (err) {
            console.error('خطأ في الحصول على عدد المنتجات:', err);
            return res.status(500).json({ message: 'حدث خطأ أثناء جلب عدد المنتجات' });
          }
          
          // المنتجات منخفضة المخزون
          db.get(`
            SELECT COUNT(*) as count 
            FROM products 
            WHERE is_active = 1 AND quantity <= min_quantity
          `, [], (err, lowStockCount) => {
            if (err) {
              console.error('خطأ في الحصول على عدد المنتجات منخفضة المخزون:', err);
              return res.status(500).json({ message: 'حدث خطأ أثناء جلب عدد المنتجات منخفضة المخزون' });
            }
            
            // آخر 5 طلبات
            db.all(`
              SELECT o.*, c.name as customer_name
              FROM orders o
              LEFT JOIN customers c ON o.customer_id = c.id
              ORDER BY o.order_date DESC
              LIMIT 5
            `, [], (err, recentOrders) => {
              if (err) {
                console.error('خطأ في الحصول على آخر الطلبات:', err);
                return res.status(500).json({ message: 'حدث خطأ أثناء جلب آخر الطلبات' });
              }
              
              // المنتجات الأكثر مبيعاً
              db.all(`
                SELECT 
                  p.id, p.name, p.sku,
                  SUM(od.quantity) as total_quantity
                FROM order_details od
                JOIN products p ON od.product_id = p.id
                JOIN orders o ON od.order_id = o.id
                WHERE o.order_status != 'cancelled'
                GROUP BY p.id
                ORDER BY total_quantity DESC
                LIMIT 5
              `, [], (err, topProducts) => {
                if (err) {
                  console.error('خطأ في الحصول على المنتجات الأكثر مبيعاً:', err);
                  return res.status(500).json({ message: 'حدث خطأ أثناء جلب المنتجات الأكثر مبيعاً' });
                }
                
                res.json({
                  sales: {
                    today: {
                      orders_count: todaySales.orders_count || 0,
                      total_sales: todaySales.total_sales || 0
                    },
                    monthly: {
                      orders_count: monthlySales.orders_count || 0,
                      total_sales: monthlySales.total_sales || 0
                    }
                  },
                  customers: {
                    total: customersCount.count || 0
                  },
                  products: {
                    total: productsCount.count || 0,
                    lowStock: lowStockCount.count || 0
                  },
                  recentOrders,
                  topProducts
                });
              });
            });
          });
        });
      });
    });
  });
});

module.exports = router;

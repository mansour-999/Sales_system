/**
 * وسيط المصادقة والتفويض
 */

const jwt = require('jsonwebtoken');
const db = require('../config/database');

// المفتاح السري لتوقيع JWT (يجب نقله إلى ملف .env في الإنتاج)
const JWT_SECRET = 'sales_system_secret_key_2025';

/**
 * التحقق من وجود المستخدم وصلاحية الوصول
 */
const authenticate = (req, res, next) => {
  try {
    // الحصول على التوكن من الكوكيز أو رأس الطلب
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: 'غير مصرح بالوصول، يرجى تسجيل الدخول' });
    }
    
    // التحقق من صحة التوكن
    jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) {
        return res.status(401).json({ message: 'التوكن غير صالح أو منتهي الصلاحية' });
      }
      
      // التحقق من وجود المستخدم في قاعدة البيانات
      db.get('SELECT * FROM users WHERE id = ? AND is_active = 1', [decoded.userId], (err, user) => {
        if (err || !user) {
          return res.status(401).json({ message: 'المستخدم غير موجود أو غير نشط' });
        }
        
        // إضافة معلومات المستخدم إلى الطلب
        req.user = {
          id: user.id,
          username: user.username,
          fullName: user.full_name,
          role: user.role
        };
        
        next();
      });
    });
  } catch (error) {
    console.error('خطأ في المصادقة:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء المصادقة' });
  }
};

/**
 * التحقق من صلاحيات المستخدم
 * @param {string[]} roles - الأدوار المسموح لها بالوصول
 */
const authorize = (roles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'غير مصرح بالوصول، يرجى تسجيل الدخول' });
    }
    
    // إذا لم يتم تحديد أدوار، السماح لجميع المستخدمين المصادق عليهم
    if (roles.length === 0) {
      return next();
    }
    
    // التحقق من وجود دور المستخدم ضمن الأدوار المسموح بها
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'غير مصرح لك بالوصول إلى هذا المورد' });
    }
    
    next();
  };
};

/**
 * إنشاء توكن JWT للمستخدم
 * @param {object} user - بيانات المستخدم
 * @returns {string} - توكن JWT
 */
const generateToken = (user) => {
  return jwt.sign(
    { 
      userId: user.id,
      username: user.username,
      role: user.role
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
};

module.exports = {
  authenticate,
  authorize,
  generateToken
};

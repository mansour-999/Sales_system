/**
 * ملف تهيئة قاعدة البيانات
 */

const { initializeDatabase } = require('./models/database');

// تهيئة قاعدة البيانات
initializeDatabase();

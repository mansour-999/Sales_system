/**
 * ملف تكوين المسارات الرئيسية
 */

const express = require('express');
const app = express();

// استيراد المسارات
const authRoutes = require('./routes/auth');
const productsRoutes = require('./routes/products');
const customersRoutes = require('./routes/customers');
const ordersRoutes = require('./routes/orders');
const invoicesRoutes = require('./routes/invoices');
const reportsRoutes = require('./routes/reports');

// تكوين مسارات API
app.use('/api/auth', authRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/customers', customersRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/invoices', invoicesRoutes);
app.use('/api/reports', reportsRoutes);

// مسارات الصفحات الرئيسية
app.get('/', (req, res) => {
  res.render('index');
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/products', (req, res) => {
  res.render('products/index');
});

app.get('/products/new', (req, res) => {
  res.render('products/new');
});

app.get('/products/:id', (req, res) => {
  res.render('products/show', { id: req.params.id });
});

app.get('/products/:id/edit', (req, res) => {
  res.render('products/edit', { id: req.params.id });
});

app.get('/customers', (req, res) => {
  res.render('customers/index');
});

app.get('/customers/new', (req, res) => {
  res.render('customers/new');
});

app.get('/customers/:id', (req, res) => {
  res.render('customers/show', { id: req.params.id });
});

app.get('/customers/:id/edit', (req, res) => {
  res.render('customers/edit', { id: req.params.id });
});

app.get('/sales', (req, res) => {
  res.render('sales/index');
});

app.get('/sales/new', (req, res) => {
  res.render('sales/new');
});

app.get('/sales/:id', (req, res) => {
  res.render('sales/show', { id: req.params.id });
});

app.get('/invoices', (req, res) => {
  res.render('invoices/index');
});

app.get('/invoices/:id', (req, res) => {
  res.render('invoices/show', { id: req.params.id });
});

app.get('/reports', (req, res) => {
  res.render('reports/index');
});

app.get('/reports/sales', (req, res) => {
  res.render('reports/sales');
});

app.get('/reports/products', (req, res) => {
  res.render('reports/products');
});

app.get('/reports/customers', (req, res) => {
  res.render('reports/customers');
});

app.get('/reports/inventory', (req, res) => {
  res.render('reports/inventory');
});

app.get('/profile', (req, res) => {
  res.render('profile');
});

app.get('/settings', (req, res) => {
  res.render('settings');
});

module.exports = app;

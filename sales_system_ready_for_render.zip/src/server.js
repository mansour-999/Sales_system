#!/usr/bin/env node

/**
 * وحدة تشغيل الخادم
 */

const app = require('./app');
const http = require('http');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();

/**
 * الحصول على المنفذ من البيئة وتخزينه في Express
 */
const port = normalizePort(process.env.PORT || '3000');
app.set('port', port);

/**
 * إنشاء خادم HTTP
 */
const server = http.createServer(app);

/**
 * التأكد من وجود قاعدة البيانات وإنشائها إذا لم تكن موجودة
 */
const dbPath = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dbPath)) {
  fs.mkdirSync(dbPath);
}

const db = new sqlite3.Database(path.join(dbPath, 'sales.db'));

/**
 * الاستماع على المنفذ المحدد لجميع واجهات الشبكة
 */
server.listen(port, '0.0.0.0');
server.on('error', onError);
server.on('listening', onListening);

/**
 * تطبيع رقم المنفذ إلى عدد صحيح، سلسلة نصية، أو false
 */
function normalizePort(val) {
  const port = parseInt(val, 10);

  if (isNaN(port)) {
    // سلسلة نصية
    return val;
  }

  if (port >= 0) {
    // رقم منفذ
    return port;
  }

  return false;
}

/**
 * معالج أحداث الخطأ للخادم HTTP
 */
function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  const bind = typeof port === 'string'
    ? 'Pipe ' + port
    : 'Port ' + port;

  // رسائل خطأ محددة للأخطاء الشائعة
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' يتطلب صلاحيات مرتفعة');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' قيد الاستخدام بالفعل');
      process.exit(1);
      break;
    default:
      throw error;
  }
}

/**
 * معالج أحداث الاستماع للخادم HTTP
 */
function onListening() {
  const addr = server.address();
  const bind = typeof addr === 'string'
    ? 'pipe ' + addr
    : 'port ' + addr.port;
  console.log('الاستماع على ' + bind);
}

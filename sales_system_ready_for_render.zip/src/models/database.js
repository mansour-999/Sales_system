/**
 * سكريبت إنشاء قاعدة البيانات
 * هذا الملف يحتوي على جميع استعلامات SQL اللازمة لإنشاء جداول قاعدة البيانات
 */

const db = require('../config/database');

// إنشاء جدول المستخدمين
const createUsersTable = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'employee',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`;

// إنشاء جدول الفئات
const createCategoriesTable = `
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  parent_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
)`;

// إنشاء جدول المنتجات
const createProductsTable = `
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  sku TEXT UNIQUE,
  barcode TEXT,
  price REAL NOT NULL DEFAULT 0,
  cost_price REAL DEFAULT 0,
  quantity INTEGER NOT NULL DEFAULT 0,
  min_quantity INTEGER DEFAULT 5,
  category_id INTEGER,
  image_path TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
)`;

// إنشاء جدول العملاء
const createCustomersTable = `
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`;

// إنشاء جدول الطلبات
const createOrdersTable = `
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER,
  user_id INTEGER NOT NULL,
  order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  total_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL DEFAULT 0,
  tax_amount REAL DEFAULT 0,
  final_amount REAL NOT NULL DEFAULT 0,
  payment_status TEXT DEFAULT 'pending',
  order_status TEXT DEFAULT 'new',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
)`;

// إنشاء جدول تفاصيل الطلبات
const createOrderDetailsTable = `
CREATE TABLE IF NOT EXISTS order_details (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price REAL NOT NULL DEFAULT 0,
  discount_percent REAL DEFAULT 0,
  total_price REAL NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT
)`;

// إنشاء جدول الفواتير
const createInvoicesTable = `
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  due_date TIMESTAMP,
  payment_method TEXT,
  payment_status TEXT DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE RESTRICT
)`;

// إنشاء جدول الخصومات والكوبونات
const createDiscountsTable = `
CREATE TABLE IF NOT EXISTS discounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE,
  type TEXT NOT NULL,
  value REAL NOT NULL,
  start_date TIMESTAMP,
  end_date TIMESTAMP,
  is_active INTEGER NOT NULL DEFAULT 1,
  min_order_amount REAL DEFAULT 0,
  max_uses INTEGER,
  current_uses INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`;

// إنشاء جدول سجل المخزون
const createInventoryLogTable = `
CREATE TABLE IF NOT EXISTS inventory_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  quantity_change INTEGER NOT NULL,
  previous_quantity INTEGER NOT NULL,
  new_quantity INTEGER NOT NULL,
  action_type TEXT NOT NULL,
  reference_id INTEGER,
  reference_type TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT,
  FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
)`;

// تنفيذ استعلامات إنشاء الجداول
const initializeDatabase = () => {
  db.serialize(() => {
    db.run(createUsersTable);
    db.run(createCategoriesTable);
    db.run(createProductsTable);
    db.run(createCustomersTable);
    db.run(createOrdersTable);
    db.run(createOrderDetailsTable);
    db.run(createInvoicesTable);
    db.run(createDiscountsTable);
    db.run(createInventoryLogTable);
    
    // إنشاء مستخدم افتراضي للنظام (admin/admin123)
    db.get("SELECT COUNT(*) as count FROM users", (err, row) => {
      if (err) {
        console.error("خطأ في التحقق من وجود مستخدمين:", err);
        return;
      }
      
      if (row.count === 0) {
        const bcrypt = require('bcrypt');
        const saltRounds = 10;
        const plainPassword = 'admin123';
        
        bcrypt.hash(plainPassword, saltRounds, (err, hash) => {
          if (err) {
            console.error("خطأ في تشفير كلمة المرور:", err);
            return;
          }
          
          const insertAdminUser = `
          INSERT INTO users (username, password, full_name, email, role)
          VALUES ('admin', ?, 'مدير النظام', 'admin@example.com', 'admin')
          `;
          
          db.run(insertAdminUser, [hash], function(err) {
            if (err) {
              console.error("خطأ في إنشاء المستخدم الافتراضي:", err);
              return;
            }
            console.log("تم إنشاء المستخدم الافتراضي بنجاح");
          });
        });
      }
    });
    
    console.log("تم إنشاء قاعدة البيانات بنجاح");
  });
};

// تصدير دالة تهيئة قاعدة البيانات
module.exports = {
  initializeDatabase
};

/**
 * تكوين قاعدة البيانات
 */

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// التأكد من وجود مجلد البيانات
const dbDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir);
}

// إنشاء اتصال بقاعدة البيانات
const db = new sqlite3.Database(path.join(dbDir, 'sales.db'));

// تصدير كائن قاعدة البيانات
module.exports = db;
